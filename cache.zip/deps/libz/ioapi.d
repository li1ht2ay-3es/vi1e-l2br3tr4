deps/libz/ioapi.o: deps/libz/ioapi.c deps/libz/zlib.h deps/libz/zconf.h \
 deps/libz/ioapi.h
