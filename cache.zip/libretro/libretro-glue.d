libretro/libretro-glue.o: libretro/libretro-glue.c \
 libretro/libretro-core.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h libretro/libretro-glue.h \
 libretro/libretro-dc.h deps/libz/zlib.h deps/libz/zconf.h \
 deps/libz/unzip.h deps/libz/zlib.h deps/libz/ioapi.h deps/7zip/7z.h \
 deps/7zip/7zTypes.h deps/7zip/7zBuf.h deps/7zip/7zCrc.h \
 deps/7zip/7zFile.h deps/7zip/7zTypes.h \
 libretro-common/include/string/stdstring.h \
 libretro-common/include/compat/strl.h \
 libretro-common/include/file/file_path.h \
 libretro-common/include/encodings/utf.h \
 libretro-common/include/compat/strcasestr.h vice/src/vicii/viciitypes.h \
 vice/src/raster/raster.h vice/src/vice.h include/sysconfig.h \
 include/config.h libretro-common/include/retro_endianness.h \
 vice/src/types.h vice/src/vice.h vice/src/vicii/vicii-timing.h \
 vice/src/c64dtv/c64dtv.h vice/src/c64dtv/c64dtvmem.h \
 vice/src/c64dtv/c64dtvmodel.h retrodep/archdep.h vice/src/archapi.h \
 deps/nibtools/nibtools.h vice/src/opencbm.h deps/nibtools/ihs.h \
 deps/nibtools/gcr.c deps/nibtools/gcr.h deps/nibtools/prot.h \
 deps/nibtools/crc.h deps/nibtools/prot.c deps/nibtools/crc.c \
 deps/nibtools/bitshifter.c deps/nibtools/lz.c
