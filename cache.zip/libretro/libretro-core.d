libretro/libretro-core.o: libretro/libretro-core.c \
 libretro-common/include/libretro.h libretro/libretro-core.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h libretro/libretro-glue.h \
 libretro/libretro-dc.h deps/libz/zlib.h deps/libz/zconf.h \
 deps/libz/unzip.h deps/libz/zlib.h deps/libz/ioapi.h deps/7zip/7z.h \
 deps/7zip/7zTypes.h deps/7zip/7zBuf.h deps/7zip/7zCrc.h \
 deps/7zip/7zFile.h deps/7zip/7zTypes.h \
 libretro-common/include/string/stdstring.h \
 libretro-common/include/compat/strl.h \
 libretro-common/include/file/file_path.h \
 libretro-common/include/encodings/utf.h \
 libretro-common/include/compat/strcasestr.h vice/src/vicii/viciitypes.h \
 vice/src/raster/raster.h vice/src/vice.h include/sysconfig.h \
 include/config.h libretro-common/include/retro_endianness.h \
 vice/src/types.h vice/src/vice.h vice/src/vicii/vicii-timing.h \
 vice/src/c128/c128.h vice/src/c128/c128mem.h vice/src/mem.h \
 vice/src/types.h vice/src/c128/c128model.h libretro/libretro-mapper.h \
 libretro/libretro-graph.h retrodep/archdep.h vice/src/archapi.h \
 vice/src/machine.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/vsyncapi.h vice/src/snapshot.h retrodep/snapshot_stream.h \
 vice/src/autostart.h vice/src/drive/drive.h vice/src/rtc/ds1216e.h \
 vice/src/lib/p64/p64.h vice/src/lib/p64/p64config.h vice/src/lib.h \
 vice/src/debug.h vice/src/drive/drivetypes.h vice/src/drive/drive.h \
 vice/src/mos6510.h vice/src/r65c02.h vice/src/tape.h \
 vice/src/diskimage.h vice/src/fsdevice.h vice/src/vdrive/vdrive.h \
 vice/src/vdrive/vdrive-dir.h vice/src/cbmdos.h \
 vice/src/vdrive/vdrive-internal.h vice/src/charset.h vice/src/attach.h \
 vice/src/interrupt.h vice/src/log.h vice/src/datasette/datasette.h \
 vice/src/cartridge.h vice/src/sound.h vice/src/initcmdline.h \
 vice/src/vsync.h vice/src/log.h vice/src/keyboard.h vice/src/kbdbuf.h \
 vice/src/resources.h vice/src/sid/sid.h vice/src/sound.h \
 vice/src/sid/sid-resources.h retrodep/uistatusbar.h \
 vice/src/userport/userport_joystick.h
