retrodep/printerdrv/drv-nl10.o: retrodep/printerdrv/drv-nl10.c
