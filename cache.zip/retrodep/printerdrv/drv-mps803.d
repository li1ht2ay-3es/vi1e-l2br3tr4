retrodep/printerdrv/drv-mps803.o: retrodep/printerdrv/drv-mps803.c
