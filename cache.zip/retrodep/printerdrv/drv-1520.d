retrodep/printerdrv/drv-1520.o: retrodep/printerdrv/drv-1520.c
