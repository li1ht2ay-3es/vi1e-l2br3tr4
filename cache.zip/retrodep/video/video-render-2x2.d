retrodep/video/video-render-2x2.o: retrodep/video/video-render-2x2.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/video/render2x2.h \
 vice/src/types.h vice/src/vice.h vice/src/video.h vice/src/types.h \
 vice/src/video/renderscale2x.h vice/src/video/video-render.h \
 vice/src/viewport.h
