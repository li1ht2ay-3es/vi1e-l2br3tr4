retrodep/monitor/monitor_network.o: retrodep/monitor/monitor_network.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/ui.h \
 vice/src/types.h vice/src/vice.h vice/src/uiapi.h vice/src/types.h \
 vice/src/cmdline.h vice/src/lib.h vice/src/debug.h vice/src/log.h \
 vice/src/monitor.h vice/src/monitor/asm.h \
 vice/src/monitor/monitor_network.h vice/src/vicesocket.h \
 vice/src/monitor/montypes.h vice/src/resources.h vice/src/util.h
