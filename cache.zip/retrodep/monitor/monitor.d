retrodep/monitor/monitor.o: retrodep/monitor/monitor.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/archdep.h \
 vice/src/archapi.h vice/src/charset.h vice/src/types.h vice/src/vice.h \
 vice/src/cmdline.h vice/src/console.h vice/src/datasette/datasette.h \
 vice/src/types.h vice/src/drive/drive.h vice/src/rtc/ds1216e.h \
 vice/src/snapshot.h retrodep/snapshot_stream.h vice/src/lib/p64/p64.h \
 vice/src/lib/p64/p64config.h vice/src/lib.h vice/src/debug.h \
 vice/src/drive/drivetypes.h vice/src/drive/drive.h vice/src/mos6510.h \
 vice/src/r65c02.h vice/src/mem.h vice/src/monitor/mon_breakpoint.h \
 vice/src/monitor/montypes.h vice/src/monitor.h vice/src/monitor/asm.h \
 vice/src/monitor/mon_disassemble.h vice/src/monitor/mon_memmap.h \
 vice/src/monitor/mon_memory.h vice/src/monitor/asm.h \
 vice/src/monitor/mon_parse.h vice/src/monitor/mon_register.h \
 vice/src/uiapi.h
