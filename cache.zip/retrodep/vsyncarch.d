retrodep/vsyncarch.o: retrodep/vsyncarch.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/kbdbuf.h \
 vice/src/types.h vice/src/vice.h retrodep/lightpendrv.h vice/src/types.h \
 retrodep/ui.h vice/src/uiapi.h retrodep/uistatusbar.h \
 vice/src/vsyncapi.h retrodep/videoarch.h vice/src/video.h \
 vice/src/resources.h libretro/libretro-core.h libretro/libretro-glue.h \
 libretro/libretro-dc.h deps/libz/zlib.h deps/libz/zconf.h \
 deps/libz/unzip.h deps/libz/zlib.h deps/libz/ioapi.h deps/7zip/7z.h \
 deps/7zip/7zTypes.h deps/7zip/7zBuf.h deps/7zip/7zCrc.h \
 deps/7zip/7zFile.h deps/7zip/7zTypes.h \
 libretro-common/include/string/stdstring.h \
 libretro-common/include/compat/strl.h \
 libretro-common/include/file/file_path.h \
 libretro-common/include/encodings/utf.h \
 libretro-common/include/compat/strcasestr.h vice/src/pet/pet.h \
 vice/src/pet/petmodel.h
