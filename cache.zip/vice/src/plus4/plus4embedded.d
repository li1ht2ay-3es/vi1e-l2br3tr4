vice/src/plus4/plus4embedded.o: vice/src/plus4/plus4embedded.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/embedded.h \
 vice/src/vice.h vice/src/types.h vice/src/palette.h vice/src/machine.h \
 vice/src/plus4/plus4mem.h vice/src/types.h \
 include/embedded/ted_yape_pal_vpl.h include/embedded/ted_yape_ntsc_vpl.h \
 include/embedded/ted_colodore_ted_vpl.h \
 include/embedded/plus4kernal005.h include/embedded/plus4kernal232.h \
 include/embedded/plus4kernal364.h include/embedded/plus4c2lo364.h
