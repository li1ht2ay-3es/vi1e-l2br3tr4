vice/src/plus4/ted-mem.o: vice/src/plus4/ted-mem.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/alarm.h \
 vice/src/types.h vice/src/vice.h vice/src/interrupt.h vice/src/debug.h \
 vice/src/log.h vice/src/joyport/joyport.h vice/src/snapshot.h \
 retrodep/snapshot_stream.h vice/src/types.h vice/src/keyboard.h \
 vice/src/log.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/vsyncapi.h vice/src/mem.h vice/src/plus4/plus4mem.h \
 vice/src/plus4/plus4pio2.h vice/src/raster/raster-changes.h \
 vice/src/raster/raster.h vice/src/viewport.h \
 vice/src/plus4/ted-badline.h vice/src/plus4/ted-fetch.h \
 vice/src/plus4/ted-irq.h vice/src/plus4/ted-mem.h \
 vice/src/plus4/ted-resources.h vice/src/plus4/ted-sound.h \
 vice/src/sound.h vice/src/plus4/ted-timer.h vice/src/plus4/ted.h \
 vice/src/plus4/tedtypes.h vice/src/raster/raster.h
