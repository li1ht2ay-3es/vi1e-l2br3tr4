vice/src/plus4/ted.o: vice/src/plus4/ted.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/videoarch.h \
 vice/src/alarm.h vice/src/types.h vice/src/vice.h vice/src/clkguard.h \
 vice/src/dma.h vice/src/lib.h vice/src/debug.h vice/src/log.h \
 vice/src/machine.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/vsyncapi.h vice/src/mem.h vice/src/plus4/plus4.h \
 vice/src/plus4/plus4mem.h vice/src/types.h \
 vice/src/raster/raster-canvas.h vice/src/raster/raster-changes.h \
 vice/src/raster/raster.h vice/src/viewport.h \
 vice/src/raster/raster-line.h vice/src/raster/raster-modes.h \
 vice/src/raster/raster-cache.h vice/src/raster/raster-sprite-cache.h \
 vice/src/resources.h vice/src/screenshot.h vice/src/viewport.h \
 vice/src/plus4/ted-cmdline-options.h vice/src/plus4/ted-color.h \
 vice/src/plus4/ted-draw.h vice/src/plus4/ted-fetch.h \
 vice/src/plus4/ted-irq.h vice/src/plus4/ted-mem.h \
 vice/src/plus4/ted-resources.h vice/src/plus4/ted-snapshot.h \
 vice/src/plus4/ted-sound.h vice/src/sound.h vice/src/plus4/ted-timer.h \
 vice/src/plus4/ted-timing.h vice/src/plus4/ted.h \
 vice/src/plus4/tedtypes.h vice/src/raster/raster.h vice/src/vsync.h \
 vice/src/video.h
