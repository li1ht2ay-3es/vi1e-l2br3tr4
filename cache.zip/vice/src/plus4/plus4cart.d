vice/src/plus4/plus4cart.o: vice/src/plus4/plus4cart.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/cartridge.h \
 vice/src/types.h vice/src/vice.h vice/src/sound.h vice/src/cmdline.h \
 vice/src/plus4/plus4cart.h vice/src/plus4/plus4mem.h vice/src/types.h \
 vice/src/log.h vice/src/util.h vice/src/machine.h vice/src/monitor.h \
 vice/src/monitor/asm.h vice/src/resources.h vice/src/sysfile.h
