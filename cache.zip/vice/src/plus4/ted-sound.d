vice/src/plus4/ted-sound.o: vice/src/plus4/ted-sound.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/plus4/digiblaster.h \
 vice/src/types.h vice/src/vice.h vice/src/sound.h vice/src/types.h \
 vice/src/lib.h vice/src/debug.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/vsyncapi.h vice/src/machine.h vice/src/plus4/plus4.h \
 vice/src/plus4/plus4speech.h vice/src/sid/sid.h vice/src/sidcart.h \
 vice/src/snapshot.h retrodep/snapshot_stream.h \
 vice/src/sid/sid-resources.h vice/src/plus4/ted-sound.h
