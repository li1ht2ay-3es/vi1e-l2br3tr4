vice/src/plus4/plus4speech.o: vice/src/plus4/plus4speech.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/alarm.h \
 vice/src/types.h vice/src/vice.h retrodep/archdep.h vice/src/archapi.h \
 vice/src/cartio.h vice/src/cmdline.h vice/src/interrupt.h \
 vice/src/debug.h vice/src/log.h vice/src/lib.h vice/src/log.h \
 vice/src/plus4/plus4.h vice/src/plus4/plus4cart.h \
 vice/src/plus4/plus4mem.h vice/src/types.h vice/src/plus4/plus4speech.h \
 vice/src/sound.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/vsyncapi.h vice/src/monitor/mon_util.h vice/src/monitor.h \
 vice/src/monitor/asm.h vice/src/resources.h vice/src/core/t6721.h \
 vice/src/util.h
