vice/src/plus4/plus4cpu.o: vice/src/plus4/plus4cpu.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/mem.h \
 vice/src/types.h vice/src/vice.h vice/src/plus4/tedtypes.h \
 vice/src/raster/raster.h vice/src/types.h vice/src/plus4/../maincpu.c \
 vice/src/plus4/../vice.h vice/src/plus4/../6510core.h \
 vice/src/plus4/../alarm.h vice/src/plus4/../types.h retrodep/archdep.h \
 vice/src/archapi.h vice/src/plus4/../clkguard.h \
 vice/src/plus4/../debug.h vice/src/plus4/../interrupt.h \
 vice/src/plus4/../log.h vice/src/plus4/../machine.h \
 vice/src/plus4/../maincpu.h vice/src/plus4/../mainlock.h \
 vice/src/plus4/../vsyncapi.h vice/src/plus4/../mem.h \
 vice/src/plus4/../monitor.h vice/src/plus4/../monitor/asm.h \
 vice/src/plus4/../mos6510.h vice/src/plus4/../h6809regs.h \
 vice/src/plus4/../snapshot.h retrodep/snapshot_stream.h \
 vice/src/plus4/../traps.h vice/src/plus4/../6510core.c
