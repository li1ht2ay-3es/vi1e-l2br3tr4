vice/src/plus4/ted-snapshot.o: vice/src/plus4/ted-snapshot.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/alarm.h \
 vice/src/types.h vice/src/vice.h vice/src/interrupt.h vice/src/debug.h \
 vice/src/log.h vice/src/log.h vice/src/mem.h vice/src/snapshot.h \
 retrodep/snapshot_stream.h vice/src/types.h \
 vice/src/raster/raster-sprite-status.h vice/src/raster/raster-sprite.h \
 vice/src/plus4/ted-irq.h vice/src/plus4/ted-snapshot.h \
 vice/src/plus4/ted.h vice/src/plus4/tedtypes.h vice/src/raster/raster.h
