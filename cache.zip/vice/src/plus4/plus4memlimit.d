vice/src/plus4/plus4memlimit.o: vice/src/plus4/plus4memlimit.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/mem.h \
 vice/src/types.h vice/src/vice.h vice/src/plus4/plus4memcsory256k.h \
 vice/src/types.h vice/src/plus4/plus4memhannes256k.h \
 vice/src/plus4/plus4memlimit.h
