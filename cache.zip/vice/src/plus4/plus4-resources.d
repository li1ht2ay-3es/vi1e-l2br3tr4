vice/src/plus4/plus4-resources.o: vice/src/plus4/plus4-resources.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/kbd.h \
 vice/src/keyboard.h vice/src/types.h vice/src/vice.h vice/src/lib.h \
 vice/src/debug.h vice/src/machine.h vice/src/mem.h \
 vice/src/plus4/plus4-resources.h vice/src/plus4/plus4mem.h \
 vice/src/types.h vice/src/plus4/plus4memcsory256k.h \
 vice/src/plus4/plus4memhacks.h vice/src/plus4/plus4memhannes256k.h \
 vice/src/plus4/plus4rom.h vice/src/plus4/plus4cart.h \
 vice/src/resources.h vice/src/util.h vice/src/vsync.h \
 vice/src/plus4/ted-resources.h
