vice/src/plus4/ted-draw.o: vice/src/plus4/ted-draw.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h \
 vice/src/raster/raster-cache-fill.h vice/src/types.h vice/src/vice.h \
 vice/src/raster/raster-cache-fill-1fff.h \
 vice/src/raster/raster-cache-nibbles.h \
 vice/src/raster/raster-cache-text-ext.h \
 vice/src/raster/raster-cache-text-std.h vice/src/raster/raster-cache.h \
 vice/src/raster/raster-sprite-cache.h vice/src/raster/raster-modes.h \
 vice/src/raster/raster-cache.h vice/src/plus4/ted-draw.h \
 vice/src/plus4/ted.h vice/src/plus4/tedtypes.h vice/src/raster/raster.h
