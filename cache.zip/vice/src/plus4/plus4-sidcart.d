vice/src/plus4/plus4-sidcart.o: vice/src/plus4/plus4-sidcart.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/cartio.h \
 vice/src/types.h vice/src/vice.h vice/src/cmdline.h \
 vice/src/plus4/digiblaster.h vice/src/types.h vice/src/sound.h \
 vice/src/joyport/joyport.h vice/src/snapshot.h \
 retrodep/snapshot_stream.h vice/src/keyboard.h vice/src/plus4/plus4.h \
 vice/src/resources.h vice/src/sid/sid.h \
 vice/src/sid/sid-cmdline-options.h vice/src/sid/sid-resources.h \
 vice/src/sidcart.h vice/src/snapshot.h vice/src/uiapi.h
