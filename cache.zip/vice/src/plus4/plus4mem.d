vice/src/plus4/plus4mem.o: vice/src/plus4/plus4mem.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/cartio.h \
 vice/src/types.h vice/src/vice.h vice/src/datasette/datasette.h \
 vice/src/types.h vice/src/plus4/digiblaster.h vice/src/sound.h \
 vice/src/iecbus.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/vsyncapi.h vice/src/mem.h vice/src/monitor.h \
 vice/src/monitor/asm.h vice/src/plus4/plus4iec.h \
 vice/src/plus4/plus4mem.h vice/src/plus4/plus4memcsory256k.h \
 vice/src/plus4/plus4memhannes256k.h vice/src/plus4/plus4memhacks.h \
 vice/src/plus4/plus4memlimit.h vice/src/plus4/plus4memrom.h \
 vice/src/plus4/plus4pio1.h vice/src/plus4/plus4pio2.h \
 vice/src/plus4/plus4tcbm.h vice/src/ram.h vice/src/resources.h \
 vice/src/tapeport/tapeport.h vice/src/snapshot.h \
 retrodep/snapshot_stream.h vice/src/plus4/ted.h vice/src/plus4/ted-mem.h \
 include/embedded/plus43plus1lo.h include/embedded/plus43plus1hi.h
