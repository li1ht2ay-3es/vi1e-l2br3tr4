vice/src/embedded.o: vice/src/embedded.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/drive/driverom.h \
 vice/src/types.h vice/src/vice.h vice/src/embedded.h vice/src/types.h \
 vice/src/palette.h include/embedded/drivedos1540.h \
 include/embedded/drivedos1541.h include/embedded/drived1541II.h
