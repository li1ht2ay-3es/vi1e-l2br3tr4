vice/src/datasette/datasette.o: vice/src/datasette/datasette.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/alarm.h \
 vice/src/types.h vice/src/vice.h vice/src/autostart.h \
 vice/src/clkguard.h vice/src/cmdline.h vice/src/datasette/datasette.h \
 vice/src/types.h vice/src/datasette/datasette-sound.h vice/src/lib.h \
 vice/src/debug.h vice/src/log.h vice/src/machine.h vice/src/maincpu.h \
 vice/src/mainlock.h vice/src/vsyncapi.h vice/src/network.h \
 vice/src/resources.h vice/src/snapshot.h retrodep/snapshot_stream.h \
 vice/src/tap.h vice/src/tape.h vice/src/tape/tape-snapshot.h \
 vice/src/tapeport/tapeport.h vice/src/uiapi.h vice/src/vice-event.h
