vice/src/scpu64/scpu64-cmdline-options.o: \
 vice/src/scpu64/scpu64-cmdline-options.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/c64/c64model.h \
 vice/src/types.h vice/src/vice.h \
 vice/src/scpu64/scpu64-cmdline-options.h \
 vice/src/scpu64/scpu64-resources.h vice/src/cmdline.h vice/src/machine.h \
 vice/src/types.h vice/src/resources.h vice/src/vicii.h
