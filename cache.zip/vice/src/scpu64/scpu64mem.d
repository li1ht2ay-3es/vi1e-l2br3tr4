vice/src/scpu64/scpu64mem.o: vice/src/scpu64/scpu64mem.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/scpu64/scpu64.h \
 vice/src/scpu64/scpu64-resources.h vice/src/c64/c64cart.h \
 vice/src/types.h vice/src/vice.h vice/src/c64/cart/expert.h \
 vice/src/c64/c64cia.h vice/src/c64/c64pla.h vice/src/scpu64/scpu64mem.h \
 vice/src/mem.h vice/src/types.h vice/src/scpu64/scpu64rom.h \
 vice/src/scpu64/scpu64meminit.h vice/src/c64/cart/c64cartmem.h \
 vice/src/cartio.h vice/src/cartridge.h vice/src/sound.h vice/src/cia.h \
 vice/src/clkguard.h vice/src/machine.h vice/src/main65816cpu.h \
 vice/src/monitor.h vice/src/monitor/asm.h vice/src/ram.h \
 vice/src/c64/cart/reu.h vice/src/sid/sid.h vice/src/sound.h \
 vice/src/viciisc/vicii-mem.h vice/src/viciisc/vicii-phi1.h \
 vice/src/vicii.h vice/src/scpu64/scpu64cpu.h vice/src/lib.h \
 vice/src/debug.h vice/src/wdc65816.h vice/src/viciisc/vicii-cycle.h \
 vice/src/traps.h vice/src/mem.h include/embedded/c64chargen.h
