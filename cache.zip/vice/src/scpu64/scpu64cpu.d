vice/src/scpu64/scpu64cpu.o: vice/src/scpu64/scpu64cpu.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/interrupt.h \
 vice/src/debug.h vice/src/types.h vice/src/vice.h vice/src/log.h \
 vice/src/6510core.h vice/src/clkguard.h vice/src/alarm.h \
 vice/src/main65816cpu.h vice/src/mem.h vice/src/scpu64/scpu64mem.h \
 vice/src/types.h vice/src/vicii.h vice/src/viciisc/vicii-cycle.h \
 vice/src/viciisc/viciitypes.h vice/src/raster/raster.h \
 vice/src/snapshot.h retrodep/snapshot_stream.h vice/src/c64/cart/reu.h \
 vice/src/scpu64/scpu64cpu.h vice/src/scpu64/../main65816cpu.c \
 vice/src/scpu64/../vice.h vice/src/scpu64/../6510core.h \
 vice/src/scpu64/../alarm.h retrodep/archdep.h vice/src/archapi.h \
 vice/src/scpu64/../clkguard.h vice/src/scpu64/../debug.h \
 vice/src/scpu64/../interrupt.h vice/src/scpu64/../log.h \
 vice/src/scpu64/../machine.h vice/src/scpu64/../types.h \
 vice/src/scpu64/../main65816cpu.h vice/src/scpu64/../mem.h \
 vice/src/scpu64/../monitor.h vice/src/scpu64/../monitor/asm.h \
 vice/src/scpu64/../snapshot.h vice/src/scpu64/../traps.h \
 vice/src/scpu64/../wdc65816.h vice/src/scpu64/../65816core.c
