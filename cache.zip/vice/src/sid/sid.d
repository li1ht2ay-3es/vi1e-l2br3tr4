vice/src/sid/sid.o: vice/src/sid/sid.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/catweaselmkiii.h \
 vice/src/types.h vice/src/vice.h vice/src/sid/sid-snapshot.h \
 vice/src/types.h vice/src/sid/fastsid.h vice/src/sid/sid.h \
 vice/src/sound.h vice/src/sid/sid-snapshot.h vice/src/hardsid.h \
 vice/src/joyport/joyport.h vice/src/snapshot.h \
 retrodep/snapshot_stream.h vice/src/lib.h vice/src/debug.h \
 vice/src/machine.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/vsyncapi.h vice/src/parsid.h vice/src/resources.h \
 vice/src/sid/sid-resources.h vice/src/ssi2001.h vice/src/joyport/mouse.h \
 vice/src/joyport/lightpen.h vice/src/joyport/joyport.h \
 vice/src/sid/resid.h
