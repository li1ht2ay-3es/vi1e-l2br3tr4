vice/src/sid/resid.o: vice/src/sid/resid.cc vice/src/vice.h \
 include/sysconfig.h include/config.h \
 libretro-common/include/retro_endianness.h \
 libretro-common/include/retro_inline.h vice/src/sid/sid.h \
 vice/src/types.h vice/src/vice.h vice/src/sound.h vice/src/types.h \
 vice/src/lib.h vice/src/debug.h vice/src/log.h vice/src/sid/resid.h \
 vice/src/resources.h vice/src/sid/sid-snapshot.h vice/src/resid/sid.h \
 vice/src/resid/resid-config.h vice/src/resid/siddefs.h \
 vice/src/resid/voice.h vice/src/resid/wave.h vice/src/resid/envelope.h \
 vice/src/resid/filter8580new.h vice/src/resid/extfilt.h \
 vice/src/resid/pot.h
