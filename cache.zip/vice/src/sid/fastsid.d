vice/src/sid/fastsid.o: vice/src/sid/fastsid.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/sid/fastsid.h \
 vice/src/types.h vice/src/vice.h vice/src/sid/sid.h vice/src/sound.h \
 vice/src/types.h vice/src/sid/sid-snapshot.h vice/src/lib.h \
 vice/src/debug.h vice/src/log.h vice/src/machine.h vice/src/maincpu.h \
 vice/src/mainlock.h vice/src/vsyncapi.h vice/src/resources.h \
 vice/src/snapshot.h retrodep/snapshot_stream.h vice/src/fixpoint.h \
 vice/src/sid/wave6581.h vice/src/sid/wave8580.h
