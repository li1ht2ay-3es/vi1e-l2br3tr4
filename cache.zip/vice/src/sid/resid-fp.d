vice/src/sid/resid-fp.o: vice/src/sid/resid-fp.cc vice/src/vice.h \
 include/sysconfig.h include/config.h \
 libretro-common/include/retro_endianness.h \
 libretro-common/include/retro_inline.h vice/src/sid/sid.h \
 vice/src/types.h vice/src/vice.h vice/src/sound.h vice/src/types.h \
 vice/src/lib.h vice/src/debug.h vice/src/log.h vice/src/resources.h \
 vice/src/sid/sid-snapshot.h \
 vice/src/residfp/builders/residfp-builder/residfp/SID.h \
 vice/src/residfp/builders/residfp-builder/residfp/../../../sysincludes.h \
 vice/src/residfp/builders/residfp-builder/residfp/siddefs-fp.h \
 vice/src/residfp/sidcxx11.h \
 vice/src/residfp/builders/residfp-builder/residfp/Filter.h \
 vice/src/residfp/builders/residfp-builder/residfp/../../../sidcxx11.h \
 vice/src/residfp/builders/residfp-builder/residfp/ExternalFilter.h \
 vice/src/residfp/builders/residfp-builder/residfp/Voice.h \
 vice/src/residfp/builders/residfp-builder/residfp/WaveformGenerator.h \
 vice/src/residfp/builders/residfp-builder/residfp/array.h \
 vice/src/residfp/builders/residfp-builder/residfp/EnvelopeGenerator.h \
 vice/src/residfp/builders/residfp-builder/residfp/resample/Resampler.h
