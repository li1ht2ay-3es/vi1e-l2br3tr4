vice/src/sid/sid-cmdline-options.o: vice/src/sid/sid-cmdline-options.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/cmdline.h \
 vice/src/hardsid.h vice/src/lib.h vice/src/vice.h vice/src/debug.h \
 vice/src/types.h vice/src/machine.h vice/src/resources.h \
 vice/src/sid/sid.h vice/src/types.h vice/src/sound.h \
 vice/src/sid/sid-cmdline-options.h vice/src/sid/sid-resources.h \
 vice/src/util.h
