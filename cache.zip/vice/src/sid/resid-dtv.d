vice/src/sid/resid-dtv.o: vice/src/sid/resid-dtv.cc vice/src/vice.h \
 include/sysconfig.h include/config.h \
 libretro-common/include/retro_endianness.h \
 libretro-common/include/retro_inline.h vice/src/sid/sid.h \
 vice/src/types.h vice/src/vice.h vice/src/sound.h vice/src/types.h \
 vice/src/lib.h vice/src/debug.h vice/src/log.h vice/src/sid/resid.h \
 vice/src/resources.h vice/src/sid/sid-snapshot.h \
 vice/src/resid-dtv/sid.h vice/src/resid-dtv/residdtv-config.h \
 vice/src/resid-dtv/siddtvdefs.h vice/src/resid-dtv/bittrain.h \
 vice/src/resid-dtv/voice.h vice/src/resid-dtv/wave.h \
 vice/src/resid-dtv/envelope.h vice/src/resid-dtv/filter.h \
 vice/src/resid-dtv/extfilt.h
