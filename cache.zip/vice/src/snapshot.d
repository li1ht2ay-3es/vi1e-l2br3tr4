vice/src/snapshot.o: vice/src/snapshot.c retrodep/snapshot_stream.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/archdep.h \
 vice/src/archapi.h vice/src/cia.h vice/src/types.h vice/src/vice.h \
 vice/src/drive/drive-snapshot.h vice/src/drive/drive.h vice/src/types.h \
 vice/src/rtc/ds1216e.h vice/src/snapshot.h retrodep/snapshot_stream.h \
 vice/src/lib/p64/p64.h vice/src/lib/p64/p64config.h vice/src/lib.h \
 vice/src/debug.h vice/src/drive/drivetypes.h vice/src/drive/drive.h \
 vice/src/mos6510.h vice/src/r65c02.h vice/src/ioutil.h \
 vice/src/joyport/joyport.h vice/src/joyport/joystick.h \
 vice/src/keyboard.h vice/src/log.h vice/src/machine.h vice/src/maincpu.h \
 vice/src/mainlock.h vice/src/vsyncapi.h vice/src/sid/sid-snapshot.h \
 vice/src/sound.h vice/src/tapeport/tapeport.h vice/src/uiapi.h \
 vice/src/userport/userport.h vice/src/version.h vice/src/vsync.h \
 vice/src/vice-event.h vice/src/zfile.h retrodep/snapshot_stream.h \
 vice/src/c64dtv/c64dtv-snapshot.c vice/src/c64dtv/c64dtv-snapshot.h \
 vice/src/c64dtv/c64dtv.h vice/src/c64/c64memsnapshot.h vice/src/vicii.h \
 vice/src/c64dtv/c64dtvdma.h vice/src/c64dtv/c64dtvblitter.h \
 vice/src/c64dtv/c64dtvmemsnapshot.h
