vice/src/vdc/vdc.o: vice/src/vdc/vdc.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/alarm.h \
 vice/src/types.h vice/src/vice.h vice/src/lib.h vice/src/debug.h \
 vice/src/log.h vice/src/machine.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/vsyncapi.h vice/src/raster/raster.h vice/src/types.h \
 vice/src/raster/raster-canvas.h vice/src/raster/raster-line.h \
 vice/src/raster/raster-modes.h vice/src/raster/raster-cache.h \
 vice/src/raster/raster-sprite-cache.h vice/src/resources.h \
 vice/src/screenshot.h vice/src/viewport.h vice/src/snapshot.h \
 retrodep/snapshot_stream.h vice/src/vdc/vdc-cmdline-options.h \
 vice/src/vdc/vdc-color.h vice/src/vdc/vdc-draw.h \
 vice/src/vdc/vdc-resources.h vice/src/vdc/vdc-snapshot.h \
 vice/src/vdc/vdc.h vice/src/vdc/vdctypes.h vice/src/video.h \
 vice/src/viewport.h
