vice/src/vdc/vdc-draw.o: vice/src/vdc/vdc-draw.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h \
 vice/src/raster/raster-cache-const.h vice/src/types.h vice/src/vice.h \
 vice/src/raster/raster-cache-fill.h vice/src/raster/raster-cache.h \
 vice/src/raster/raster-sprite-cache.h vice/src/raster/raster-modes.h \
 vice/src/raster/raster-cache.h vice/src/vdc/vdc-draw.h \
 vice/src/vdc/vdc-resources.h vice/src/vdc/vdc.h vice/src/vdc/vdctypes.h \
 vice/src/raster/raster.h
