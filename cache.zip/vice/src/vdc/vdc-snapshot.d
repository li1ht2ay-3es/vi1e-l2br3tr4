vice/src/vdc/vdc-snapshot.o: vice/src/vdc/vdc-snapshot.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/log.h \
 vice/src/snapshot.h retrodep/snapshot_stream.h vice/src/types.h \
 vice/src/vice.h vice/src/vdc/vdc-snapshot.h vice/src/vdc/vdc.h \
 vice/src/vdc/vdctypes.h vice/src/raster/raster.h
