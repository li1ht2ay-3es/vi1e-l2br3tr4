vice/src/vicii/vicii-stubs.o: vice/src/vicii/vicii-stubs.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h \
 vice/src/c64dtv/c64dtvblitter.h vice/src/types.h vice/src/vice.h \
 vice/src/c64dtv/c64dtvdma.h
