vice/src/vicii/vicii-resources.o: vice/src/vicii/vicii-resources.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/archdep.h \
 vice/src/archapi.h vice/src/fullscreen.h vice/src/machine.h \
 vice/src/types.h vice/src/vice.h vice/src/raster/raster-resources.h \
 vice/src/resources.h vice/src/vicii/vicii-color.h \
 vice/src/vicii/vicii-resources.h vice/src/vicii/vicii-timing.h \
 vice/src/vicii.h vice/src/vicii/viciitypes.h vice/src/raster/raster.h \
 vice/src/types.h vice/src/video.h vice/src/vsync.h
