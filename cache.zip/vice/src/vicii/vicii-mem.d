vice/src/vicii/vicii-mem.o: vice/src/vicii/vicii-mem.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/alarm.h \
 vice/src/types.h vice/src/vice.h vice/src/c64/c64cia.h vice/src/types.h \
 vice/src/debug.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/vsyncapi.h vice/src/mem.h vice/src/raster/raster-changes.h \
 vice/src/raster/raster.h vice/src/viewport.h \
 vice/src/raster/raster-sprite-status.h vice/src/raster/raster-sprite.h \
 vice/src/vicii/vicii-badline.h vice/src/vicii/vicii-fetch.h \
 vice/src/vicii/vicii-irq.h vice/src/vicii/vicii-resources.h \
 vice/src/vicii/vicii-sprites.h vice/src/vicii/vicii-mem.h \
 vice/src/vicii.h vice/src/vicii/viciitypes.h vice/src/raster/raster.h
