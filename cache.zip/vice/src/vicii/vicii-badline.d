vice/src/vicii/vicii-badline.o: vice/src/vicii/vicii-badline.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/dma.h \
 vice/src/types.h vice/src/vice.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/vsyncapi.h vice/src/raster/raster-changes.h \
 vice/src/raster/raster.h vice/src/types.h vice/src/viewport.h \
 vice/src/vicii/vicii-badline.h vice/src/vicii/vicii-fetch.h \
 vice/src/vicii/viciitypes.h vice/src/raster/raster.h
