vice/src/vicii/vicii-sprites.o: vice/src/vicii/vicii-sprites.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/lib.h \
 vice/src/vice.h vice/src/debug.h vice/src/types.h \
 vice/src/raster/raster-cache.h vice/src/raster/raster-sprite-cache.h \
 vice/src/types.h vice/src/raster/raster-changes.h \
 vice/src/raster/raster.h vice/src/viewport.h \
 vice/src/raster/raster-sprite-status.h vice/src/raster/raster-sprite.h \
 vice/src/vicii/vicii-sprites.h vice/src/vicii/viciitypes.h \
 vice/src/raster/raster.h
