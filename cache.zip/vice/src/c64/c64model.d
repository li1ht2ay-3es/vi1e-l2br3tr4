vice/src/c64/c64model.o: vice/src/c64/c64model.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/c64/c64-resources.h \
 vice/src/c64/c64iec.h vice/src/c64/c64keyboard.h vice/src/c64/c64model.h \
 vice/src/types.h vice/src/vice.h vice/src/cia.h vice/src/types.h \
 vice/src/machine.h vice/src/resources.h vice/src/sid/sid.h \
 vice/src/sound.h vice/src/tapeport/tapeport.h vice/src/snapshot.h \
 retrodep/snapshot_stream.h vice/src/userport/userport.h vice/src/vicii.h
