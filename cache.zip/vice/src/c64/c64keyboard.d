vice/src/c64/c64keyboard.o: vice/src/c64/c64keyboard.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/c64/c64cia.h \
 vice/src/types.h vice/src/vice.h vice/src/c64/c64keyboard.h \
 vice/src/interrupt.h vice/src/debug.h vice/src/types.h vice/src/log.h \
 vice/src/joyport/joystick.h vice/src/keyboard.h vice/src/machine.h \
 vice/src/maincpu.h vice/src/mainlock.h vice/src/vsyncapi.h \
 vice/src/vicii.h
