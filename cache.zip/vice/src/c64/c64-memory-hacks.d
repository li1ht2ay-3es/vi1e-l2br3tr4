vice/src/c64/c64-memory-hacks.o: vice/src/c64/c64-memory-hacks.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h \
 vice/src/c64/c64-memory-hacks.h vice/src/snapshot.h \
 retrodep/snapshot_stream.h vice/src/types.h vice/src/vice.h \
 vice/src/c64/c64_256k.h vice/src/cmdline.h vice/src/mem.h \
 vice/src/types.h vice/src/c64/plus256k.h vice/src/c64/plus60k.h \
 vice/src/resources.h retrodep/ui.h vice/src/uiapi.h
