vice/src/c64/psid.o: vice/src/c64/psid.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/archdep.h \
 vice/src/archapi.h vice/src/c64/c64mem.h vice/src/mem.h vice/src/types.h \
 vice/src/vice.h vice/src/types.h vice/src/c64/c64rom.h \
 vice/src/c64/c64-resources.h vice/src/charset.h vice/src/cmdline.h \
 vice/src/lib.h vice/src/debug.h vice/src/log.h vice/src/machine.h \
 vice/src/c64/patchrom.h vice/src/c64/psid.h vice/src/resources.h \
 vice/src/uiapi.h vice/src/vsidui.h vice/src/vsync.h vice/src/zfile.h \
 vice/src/c64/psiddrv.h vice/src/c64/musdrv.h
