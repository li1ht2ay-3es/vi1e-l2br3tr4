vice/src/c64/c64-resources.o: vice/src/c64/c64-resources.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/c64/c64-resources.h \
 vice/src/c64/cart/c64acia.h vice/src/types.h vice/src/vice.h \
 vice/src/c64/c64cart.h vice/src/c64/cart/expert.h vice/src/c64/c64cia.h \
 vice/src/c64/c64rom.h vice/src/c64/c64memrom.h vice/src/c64/c64mem.h \
 vice/src/mem.h vice/src/types.h vice/src/c64/c64model.h \
 vice/src/cartio.h vice/src/cartridge.h vice/src/sound.h vice/src/cia.h \
 vice/src/lib.h vice/src/debug.h vice/src/log.h vice/src/machine.h \
 vice/src/c64/patchrom.h vice/src/resources.h vice/src/c64/cart/reu.h \
 vice/src/c64/cart/georam.h vice/src/sid/sid-resources.h vice/src/util.h \
 vice/src/vicii/vicii-resources.h vice/src/vicii.h \
 vice/src/c64/c64fastiec.h
