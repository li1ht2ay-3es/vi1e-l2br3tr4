vice/src/c64/c64embedded.o: vice/src/c64/c64embedded.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/c64/c64mem.h \
 vice/src/mem.h vice/src/types.h vice/src/vice.h vice/src/types.h \
 vice/src/embedded.h vice/src/palette.h vice/src/machine.h \
 include/embedded/vicii_c64hq_vpl.h include/embedded/vicii_c64s_vpl.h \
 include/embedded/vicii_ccs64_vpl.h include/embedded/vicii_cjam_vpl.h \
 include/embedded/vicii_colodore_vpl.h \
 include/embedded/vicii_community_colors_vpl.h \
 include/embedded/vicii_deekay_vpl.h include/embedded/vicii_frodo_vpl.h \
 include/embedded/vicii_godot_vpl.h include/embedded/vicii_pc64_vpl.h \
 include/embedded/vicii_pepto_ntsc_vpl.h \
 include/embedded/vicii_pepto_ntsc_sony_vpl.h \
 include/embedded/vicii_pepto_pal_vpl.h \
 include/embedded/vicii_pepto_palold_vpl.h \
 include/embedded/vicii_ptoing_vpl.h include/embedded/vicii_rgb_vpl.h \
 include/embedded/vicii_vice_vpl.h include/embedded/c64gskernal.h \
 include/embedded/c64edkernal.h include/embedded/c64sxkernal.h \
 include/embedded/c64jpkernal.h include/embedded/c64jpchrgen.h \
 vice/src/scpu64/scpu64mem.h include/embedded/scpu64kernal.h
