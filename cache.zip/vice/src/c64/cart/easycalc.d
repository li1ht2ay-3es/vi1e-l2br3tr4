vice/src/c64/cart/easycalc.o: vice/src/c64/cart/easycalc.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h \
 vice/src/c64/cart/c64cartsystem.h vice/src/types.h vice/src/vice.h \
 vice/src/cartridge.h vice/src/types.h vice/src/sound.h \
 vice/src/c64/cart/crt.h vice/src/c64/cart/easycalc.h \
 vice/src/c64/c64cart.h vice/src/c64/cart/expert.h vice/src/export.h \
 vice/src/cartio.h vice/src/monitor.h vice/src/monitor/asm.h \
 vice/src/snapshot.h retrodep/snapshot_stream.h vice/src/util.h
