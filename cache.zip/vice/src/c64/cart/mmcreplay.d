vice/src/c64/cart/mmcreplay.o: vice/src/c64/cart/mmcreplay.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/archdep.h \
 vice/src/archapi.h vice/src/c64/cart/c64cartsystem.h vice/src/types.h \
 vice/src/vice.h vice/src/c64/c64mem.h vice/src/mem.h vice/src/types.h \
 vice/src/c64/c64pla.h vice/src/cartio.h vice/src/cartridge.h \
 vice/src/sound.h vice/src/c64/cart/clockport.h vice/src/cmdline.h \
 vice/src/c64/cart/crt.h vice/src/export.h vice/src/cartio.h \
 vice/src/flash040.h vice/src/lib.h vice/src/debug.h vice/src/log.h \
 vice/src/machine.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/vsyncapi.h vice/src/monitor.h vice/src/monitor/asm.h \
 vice/src/resources.h vice/src/core/ser-eeprom.h vice/src/snapshot.h \
 retrodep/snapshot_stream.h vice/src/core/spi-sdcard.h vice/src/util.h \
 vice/src/viciisc/vicii-phi1.h vice/src/c64/cart/mmcreplay.h \
 vice/src/c64/cart/reu.h
