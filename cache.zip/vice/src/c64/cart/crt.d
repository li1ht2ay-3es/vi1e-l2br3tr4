vice/src/c64/cart/crt.o: vice/src/c64/cart/crt.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/archdep.h \
 vice/src/archapi.h vice/src/cartridge.h vice/src/types.h vice/src/vice.h \
 vice/src/sound.h vice/src/c64/cart/crt.h vice/src/types.h vice/src/log.h \
 vice/src/resources.h vice/src/c64/c64cart.h vice/src/c64/cart/expert.h \
 vice/src/c64/cart/actionreplay.h vice/src/c64/cart/actionreplay2.h \
 vice/src/c64/cart/actionreplay3.h vice/src/c64/cart/actionreplay4.h \
 vice/src/c64/cart/atomicpower.h vice/src/c64/cart/bisplus.h \
 vice/src/c64/cart/blackbox3.h vice/src/c64/cart/blackbox4.h \
 vice/src/c64/cart/blackbox8.h vice/src/c64/cart/blackbox9.h \
 vice/src/c64/cart/c64-generic.h vice/src/c64/cart/c64tpi.h \
 vice/src/c64/cart/comal80.h vice/src/c64/cart/capture.h \
 vice/src/c64/cart/delaep256.h vice/src/c64/cart/delaep64.h \
 vice/src/c64/cart/delaep7x8.h vice/src/c64/cart/diashowmaker.h \
 vice/src/c64/cart/dinamic.h vice/src/c64/cart/easycalc.h \
 vice/src/c64/cart/easyflash.h vice/src/c64/cart/epyxfastload.h \
 vice/src/c64/cart/exos.h vice/src/c64/cart/expert.h \
 vice/src/c64/cart/final.h vice/src/c64/cart/finalplus.h \
 vice/src/c64/cart/final3.h vice/src/c64/cart/formel64.h \
 vice/src/c64/cart/freezeframe.h vice/src/c64/cart/freezemachine.h \
 vice/src/c64/cart/funplay.h vice/src/c64/cart/gamekiller.h \
 vice/src/c64/cart/gmod2.h vice/src/c64/cart/gmod3.h \
 vice/src/c64/cart/gs.h vice/src/c64/cart/hero.h \
 vice/src/c64/cart/ide64.h vice/src/c64/cart/isepic.h \
 vice/src/c64/cart/kcs.h vice/src/c64/cart/kingsoft.h \
 vice/src/c64/cart/ltkernal.h vice/src/c64/cart/mach5.h \
 vice/src/c64/cart/magicdesk.h vice/src/c64/cart/magicformel.h \
 vice/src/c64/cart/magicvoice.h vice/src/sound.h \
 vice/src/c64/cart/maxbasic.h vice/src/c64/cart/mikroass.h \
 vice/src/c64/cart/mmc64.h vice/src/c64/cart/mmcreplay.h \
 vice/src/c64/cart/multimax.h vice/src/c64/cart/ocean.h \
 vice/src/c64/cart/pagefox.h vice/src/c64/cart/prophet64.h \
 vice/src/c64/cart/ramlink.h vice/src/c64/cart/retroreplay.h \
 vice/src/c64/cart/rexep256.h vice/src/c64/cart/rexramfloppy.h \
 vice/src/c64/cart/rexutility.h vice/src/c64/cart/rgcd.h \
 vice/src/c64/cart/rrnetmk3.h vice/src/c64/cart/ross.h \
 vice/src/c64/cart/sdbox.h vice/src/c64/cart/silverrock128.h \
 vice/src/c64/cart/simonsbasic.h vice/src/c64/cart/stardos.h \
 vice/src/c64/cart/stb.h vice/src/c64/cart/snapshot64.h \
 vice/src/c64/cart/supergames.h vice/src/c64/cart/supersnapshot4.h \
 vice/src/c64/cart/supersnapshot.h vice/src/c64/cart/superexplode5.h \
 vice/src/c64/cart/warpspeed.h vice/src/c64/cart/westermann.h \
 vice/src/c64/cart/zaxxon.h vice/src/c64/cart/zippcode48.h \
 vice/src/util.h
