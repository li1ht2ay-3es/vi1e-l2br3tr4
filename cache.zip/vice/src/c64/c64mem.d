vice/src/c64/c64mem.o: vice/src/c64/c64mem.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/alarm.h \
 vice/src/types.h vice/src/vice.h vice/src/c64/c64.h \
 vice/src/c64/c64-memory-hacks.h vice/src/snapshot.h \
 retrodep/snapshot_stream.h vice/src/types.h vice/src/c64/c64-resources.h \
 vice/src/c64/c64_256k.h vice/src/c64/c64cart.h \
 vice/src/c64/cart/expert.h vice/src/c64/c64cia.h vice/src/c64/c64mem.h \
 vice/src/mem.h vice/src/c64/c64meminit.h vice/src/c64/c64memlimit.h \
 vice/src/c64/c64memrom.h vice/src/c64/c64pla.h vice/src/c64ui.h \
 vice/src/c64/cart/c64cartmem.h vice/src/cartio.h vice/src/cartridge.h \
 vice/src/sound.h vice/src/cia.h vice/src/clkguard.h vice/src/machine.h \
 vice/src/maincpu.h vice/src/mainlock.h vice/src/vsyncapi.h \
 vice/src/monitor.h vice/src/monitor/asm.h vice/src/c64/plus256k.h \
 vice/src/c64/plus60k.h vice/src/ram.h vice/src/resources.h \
 vice/src/c64/cart/reu.h vice/src/sid/sid.h vice/src/sound.h \
 vice/src/tpi.h vice/src/vicii/vicii-mem.h vice/src/vicii/vicii-phi1.h \
 vice/src/vicii.h include/embedded/c64chargen.h
