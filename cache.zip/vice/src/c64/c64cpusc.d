vice/src/c64/c64cpusc.o: vice/src/c64/c64cpusc.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/c64/cart/cpmcart.h \
 vice/src/snapshot.h retrodep/snapshot_stream.h vice/src/types.h \
 vice/src/vice.h vice/src/monitor.h vice/src/types.h \
 vice/src/monitor/asm.h vice/src/viciisc/vicii-cycle.h \
 vice/src/c64/../mainc64cpu.c vice/src/c64/../vice.h \
 vice/src/c64/../6510core.h vice/src/c64/../alarm.h \
 vice/src/c64/../types.h retrodep/archdep.h vice/src/archapi.h \
 vice/src/c64/../clkguard.h vice/src/c64/../debug.h \
 vice/src/c64/../interrupt.h vice/src/c64/../log.h \
 vice/src/c64/../machine.h vice/src/c64/../mainc64cpu.h \
 vice/src/c64/../maincpu.h vice/src/c64/../mainlock.h \
 vice/src/c64/../vsyncapi.h vice/src/c64/../mem.h \
 vice/src/c64/../monitor.h vice/src/c64/../mos6510.h \
 vice/src/c64/cart/reu.h vice/src/c64/../snapshot.h \
 vice/src/c64/../traps.h vice/src/c64/../6510dtvcore.c
