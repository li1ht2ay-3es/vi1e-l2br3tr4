vice/src/attach.o: vice/src/attach.c vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/attach.h \
 vice/src/types.h vice/src/cmdline.h vice/src/diskimage.h \
 vice/src/drive/driveimage.h vice/src/fsdevice.h vice/src/fliplist.h \
 vice/src/lib.h vice/src/debug.h vice/src/log.h vice/src/machine-bus.h \
 vice/src/machine-drive.h vice/src/network.h vice/src/resources.h \
 vice/src/serial.h vice/src/uiapi.h vice/src/vdrive/vdrive-bam.h \
 vice/src/types.h vice/src/vdrive/vdrive-iec.h vice/src/vdrive/vdrive.h \
 vice/src/vdrive/vdrive-dir.h vice/src/cbmdos.h vice/src/types.h \
 vice/src/vice-event.h vice/src/lib/p64/p64.h \
 vice/src/lib/p64/p64config.h vice/src/lib.h
