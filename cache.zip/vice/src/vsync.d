vice/src/vsync.o: vice/src/vsync.c vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h \
 vice/src/arch/shared/archdep_exit.h vice/src/clkguard.h vice/src/types.h \
 vice/src/cmdline.h vice/src/debug.h retrodep/joy.h retrodep/kbd.h \
 vice/src/kbdbuf.h vice/src/lib.h vice/src/log.h vice/src/maincpu.h \
 vice/src/mainlock.h vice/src/vsyncapi.h vice/src/machine.h \
 vice/src/network.h vice/src/resources.h vice/src/sound.h vice/src/tick.h \
 vice/src/vsync.h retrodep/ui.h vice/src/vice.h vice/src/types.h \
 vice/src/uiapi.h vice/src/types.h vice/src/monitor.h \
 vice/src/monitor/asm.h
