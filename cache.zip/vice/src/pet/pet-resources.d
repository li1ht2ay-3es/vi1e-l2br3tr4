vice/src/pet/pet-resources.o: vice/src/pet/pet-resources.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/crtc/crtc.h \
 vice/src/types.h vice/src/vice.h retrodep/kbd.h vice/src/keyboard.h \
 vice/src/types.h vice/src/lib.h vice/src/debug.h vice/src/machine.h \
 vice/src/pet/pet-resources.h vice/src/pet/pet.h vice/src/pet/petcolour.h \
 vice/src/pet/petmem.h vice/src/mem.h vice/src/pet/petrom.h \
 vice/src/pet/pets.h vice/src/resources.h vice/src/util.h
