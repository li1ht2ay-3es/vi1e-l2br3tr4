vice/src/pet/petcolour.o: vice/src/pet/petcolour.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/crtc/crtc.h \
 vice/src/types.h vice/src/vice.h vice/src/crtc/crtc-color.h \
 vice/src/crtc/crtctypes.h vice/src/crtc/crtc.h vice/src/raster/raster.h \
 vice/src/pet/pet.h vice/src/pet/petcolour.h vice/src/pet/petmem.h \
 vice/src/mem.h vice/src/types.h vice/src/pet/pets.h \
 vice/src/pet/pet-resources.h vice/src/video.h
