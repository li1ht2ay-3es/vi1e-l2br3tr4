vice/src/pet/petmem.o: vice/src/pet/petmem.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/pet/6809.h \
 vice/src/alarm.h vice/src/types.h vice/src/vice.h vice/src/interrupt.h \
 vice/src/debug.h vice/src/log.h vice/src/cartio.h vice/src/cartridge.h \
 vice/src/sound.h vice/src/crtc/crtc-mem.h vice/src/types.h \
 vice/src/crtc/crtctypes.h vice/src/crtc/crtc.h vice/src/raster/raster.h \
 vice/src/lib.h vice/src/log.h vice/src/machine.h vice/src/maincpu.h \
 vice/src/mainlock.h vice/src/vsyncapi.h vice/src/mem.h \
 vice/src/monitor.h vice/src/monitor/asm.h vice/src/pet/pet.h \
 vice/src/pet/pet-resources.h vice/src/pet/petacia.h \
 vice/src/pet/petcolour.h vice/src/pet/petdww.h vice/src/pet/pethre.h \
 vice/src/pet/petmem.h vice/src/pet/petmodel.h vice/src/pet/petpia.h \
 vice/src/pet/pets.h vice/src/pet/petvia.h vice/src/ram.h \
 vice/src/resources.h vice/src/via.h vice/src/vsync.h
