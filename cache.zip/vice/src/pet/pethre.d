vice/src/pet/pethre.o: vice/src/pet/pethre.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/cmdline.h \
 vice/src/crtc/crtc-draw.h vice/src/types.h vice/src/vice.h \
 vice/src/crtc/crtc.h vice/src/crtc/crtctypes.h vice/src/crtc/crtc.h \
 vice/src/raster/raster.h vice/src/log.h vice/src/monitor.h \
 vice/src/types.h vice/src/monitor/asm.h vice/src/pet/pethre.h \
 vice/src/mem.h vice/src/pet/petmem.h vice/src/pet/pets.h \
 vice/src/resources.h vice/src/snapshot.h retrodep/snapshot_stream.h
