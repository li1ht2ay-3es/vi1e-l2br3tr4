vice/src/pet/petrom.o: vice/src/pet/petrom.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/autostart.h \
 vice/src/types.h vice/src/vice.h vice/src/kbdbuf.h vice/src/crtc/crtc.h \
 vice/src/types.h vice/src/log.h vice/src/mem.h vice/src/pet/pet.h \
 vice/src/pet/petmem.h vice/src/pet/petrom.h vice/src/pet/pets.h \
 vice/src/resources.h vice/src/sysfile.h vice/src/tape.h vice/src/traps.h \
 vice/src/mem.h vice/src/util.h
