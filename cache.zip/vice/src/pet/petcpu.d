vice/src/pet/petcpu.o: vice/src/pet/petcpu.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/maincpu.h \
 vice/src/mainlock.h vice/src/vice.h vice/src/types.h vice/src/vsyncapi.h \
 vice/src/mem.h vice/src/pet/pets.h vice/src/types.h vice/src/pet/6809.h \
 vice/src/alarm.h vice/src/interrupt.h vice/src/debug.h vice/src/log.h \
 vice/src/pet/../maincpu.c vice/src/pet/../vice.h \
 vice/src/pet/../6510core.h vice/src/pet/../alarm.h retrodep/archdep.h \
 vice/src/archapi.h vice/src/pet/../clkguard.h vice/src/pet/../types.h \
 vice/src/pet/../debug.h vice/src/pet/../interrupt.h \
 vice/src/pet/../log.h vice/src/pet/../machine.h \
 vice/src/pet/../maincpu.h vice/src/pet/../mainlock.h \
 vice/src/pet/../mem.h vice/src/pet/../monitor.h \
 vice/src/pet/../monitor/asm.h vice/src/pet/../mos6510.h \
 vice/src/pet/../h6809regs.h vice/src/pet/../snapshot.h \
 retrodep/snapshot_stream.h vice/src/pet/../traps.h \
 vice/src/pet/../6510core.c
