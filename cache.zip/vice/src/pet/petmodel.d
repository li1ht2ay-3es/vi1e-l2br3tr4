vice/src/pet/petmodel.o: vice/src/pet/petmodel.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/machine.h \
 vice/src/types.h vice/src/vice.h vice/src/pet/pet-resources.h \
 vice/src/pet/petmem.h vice/src/mem.h vice/src/types.h \
 vice/src/pet/petmodel.h vice/src/pet/pets.h vice/src/resources.h \
 vice/src/uiapi.h vice/src/vsync.h
