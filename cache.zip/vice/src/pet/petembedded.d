vice/src/pet/petembedded.o: vice/src/pet/petembedded.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/embedded.h \
 vice/src/vice.h vice/src/types.h vice/src/palette.h vice/src/machine.h \
 vice/src/pet/pets.h vice/src/types.h include/embedded/petbasic1.h \
 include/embedded/petbasic2.h include/embedded/petbasic4.h \
 include/embedded/petchargen.h include/embedded/petedit1g.h \
 include/embedded/petedit2b.h include/embedded/petedit2g.h \
 include/embedded/petedit4b40.h include/embedded/petedit4b80.h \
 include/embedded/petedit4g40.h include/embedded/petkernal1.h \
 include/embedded/petkernal2.h include/embedded/petkernal4.h \
 include/embedded/superpet_char.h \
 include/embedded/superpet_waterloo_a000.h \
 include/embedded/superpet_waterloo_b000.h \
 include/embedded/superpet_waterloo_c000.h \
 include/embedded/superpet_waterloo_d000.h \
 include/embedded/superpet_waterloo_e000.h \
 include/embedded/superpet_waterloo_f000.h \
 include/embedded/crtc_amber_vpl.h include/embedded/crtc_green_vpl.h \
 include/embedded/crtc_white_vpl.h
