vice/src/pet/petvia.o: vice/src/pet/petvia.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/crtc/crtc.h \
 vice/src/types.h vice/src/vice.h vice/src/datasette/datasette.h \
 vice/src/drive/drive.h vice/src/rtc/ds1216e.h vice/src/snapshot.h \
 retrodep/snapshot_stream.h vice/src/lib/p64/p64.h \
 vice/src/lib/p64/p64config.h vice/src/lib.h vice/src/debug.h \
 vice/src/types.h vice/src/drive/drivetypes.h vice/src/drive/drive.h \
 vice/src/mos6510.h vice/src/r65c02.h vice/src/interrupt.h vice/src/log.h \
 vice/src/joyport/joystick.h vice/src/keyboard.h vice/src/log.h \
 vice/src/maincpu.h vice/src/mainlock.h vice/src/vsyncapi.h \
 vice/src/parallel.h vice/src/pet/pet.h vice/src/pet/petsound.h \
 vice/src/sound.h vice/src/pet/petvia.h vice/src/tapeport/tapeport.h \
 vice/src/userport/userport.h vice/src/via.h
