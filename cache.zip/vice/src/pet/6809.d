vice/src/pet/6809.o: vice/src/pet/6809.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/pet/6809.h \
 vice/src/alarm.h vice/src/types.h vice/src/vice.h vice/src/interrupt.h \
 vice/src/debug.h vice/src/log.h vice/src/h6809regs.h vice/src/monitor.h \
 vice/src/monitor/asm.h vice/src/types.h vice/src/pet/petmem.h \
 vice/src/mem.h vice/src/snapshot.h retrodep/snapshot_stream.h \
 vice/src/machine.h
