vice/src/keyboard.o: vice/src/keyboard.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/alarm.h \
 vice/src/types.h retrodep/archdep.h vice/src/archapi.h \
 vice/src/arch/shared/archdep_kbd_get_host_mapping.h vice/src/cmdline.h \
 vice/src/joyport/joystick.h vice/src/types.h retrodep/joy.h \
 retrodep/kbd.h retrodep/kbd.h vice/src/keyboard.h vice/src/lib.h \
 vice/src/debug.h vice/src/log.h vice/src/machine.h vice/src/maincpu.h \
 vice/src/mainlock.h vice/src/vsyncapi.h vice/src/network.h \
 vice/src/resources.h vice/src/snapshot.h retrodep/snapshot_stream.h \
 vice/src/sysfile.h vice/src/util.h vice/src/vice-event.h \
 retrodep/keymap.c
