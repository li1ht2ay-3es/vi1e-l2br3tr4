vice/src/fileio/fileio.o: vice/src/fileio/fileio.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/fileio/cbmfile.h \
 vice/src/types.h vice/src/vice.h vice/src/fileio.h vice/src/types.h \
 vice/src/lib.h vice/src/debug.h vice/src/fileio/p00.h vice/src/util.h
