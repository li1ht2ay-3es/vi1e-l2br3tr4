vice/src/resid-dtv/extfilt.o: vice/src/resid-dtv/extfilt.cc \
 vice/src/resid-dtv/extfilt.h vice/src/resid-dtv/residdtv-config.h \
 vice/src/resid-dtv/siddtvdefs.h
