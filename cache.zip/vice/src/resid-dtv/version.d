vice/src/resid-dtv/version.o: vice/src/resid-dtv/version.cc \
 vice/src/resid-dtv/residdtv-config.h vice/src/resid-dtv/siddtvdefs.h
