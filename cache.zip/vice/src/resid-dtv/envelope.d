vice/src/resid-dtv/envelope.o: vice/src/resid-dtv/envelope.cc \
 vice/src/resid-dtv/envelope.h vice/src/resid-dtv/residdtv-config.h \
 vice/src/resid-dtv/siddtvdefs.h vice/src/resid-dtv/bittrain.h
