vice/src/resid-dtv/filter.o: vice/src/resid-dtv/filter.cc \
 vice/src/resid-dtv/filter.h vice/src/resid-dtv/residdtv-config.h \
 vice/src/resid-dtv/siddtvdefs.h
