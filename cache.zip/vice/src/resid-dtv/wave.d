vice/src/resid-dtv/wave.o: vice/src/resid-dtv/wave.cc \
 vice/src/resid-dtv/wave.h vice/src/resid-dtv/residdtv-config.h \
 vice/src/resid-dtv/siddtvdefs.h vice/src/resid-dtv/bittrain.h
