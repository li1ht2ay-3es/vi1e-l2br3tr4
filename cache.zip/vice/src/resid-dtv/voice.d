vice/src/resid-dtv/voice.o: vice/src/resid-dtv/voice.cc \
 vice/src/resid-dtv/voice.h vice/src/resid-dtv/residdtv-config.h \
 vice/src/resid-dtv/siddtvdefs.h vice/src/resid-dtv/wave.h \
 vice/src/resid-dtv/bittrain.h vice/src/resid-dtv/envelope.h
