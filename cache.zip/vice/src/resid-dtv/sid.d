vice/src/resid-dtv/sid.o: vice/src/resid-dtv/sid.cc \
 vice/src/resid-dtv/sid.h vice/src/resid-dtv/residdtv-config.h \
 vice/src/resid-dtv/siddtvdefs.h vice/src/resid-dtv/bittrain.h \
 vice/src/resid-dtv/voice.h vice/src/resid-dtv/wave.h \
 vice/src/resid-dtv/envelope.h vice/src/resid-dtv/filter.h \
 vice/src/resid-dtv/extfilt.h
