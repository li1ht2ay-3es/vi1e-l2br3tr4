vice/src/c128/c128memsnapshot.o: vice/src/c128/c128memsnapshot.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/c64/c64cart.h \
 vice/src/types.h vice/src/vice.h vice/src/c64/cart/expert.h \
 vice/src/c128/c128.h vice/src/c128/c128-resources.h \
 vice/src/c128/c128mem.h vice/src/mem.h vice/src/types.h \
 vice/src/c128/c128memrom.h vice/src/c128/c128memsnapshot.h \
 vice/src/c128/c128mmu.h vice/src/c128/c128rom.h vice/src/cartridge.h \
 vice/src/sound.h vice/src/log.h vice/src/resources.h vice/src/snapshot.h \
 retrodep/snapshot_stream.h vice/src/tpi.h vice/src/uiapi.h
