vice/src/c128/c128-cmdline-options.o: \
 vice/src/c128/c128-cmdline-options.c vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h \
 vice/src/c128/c128-cmdline-options.h vice/src/c128/c128-resources.h \
 vice/src/c128/c128model.h vice/src/types.h vice/src/vice.h \
 vice/src/cmdline.h vice/src/machine.h vice/src/types.h
