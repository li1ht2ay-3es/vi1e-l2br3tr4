vice/src/c128/c128cia1.o: vice/src/c128/c128cia1.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h \
 vice/src/c128/c128-resources.h vice/src/c128/c128fastiec.h \
 vice/src/types.h vice/src/vice.h vice/src/c64/c64.h \
 vice/src/c64/c64cia.h vice/src/cia.h vice/src/types.h \
 vice/src/clkguard.h vice/src/drive/drive.h vice/src/rtc/ds1216e.h \
 vice/src/snapshot.h retrodep/snapshot_stream.h vice/src/lib/p64/p64.h \
 vice/src/lib/p64/p64config.h vice/src/lib.h vice/src/debug.h \
 vice/src/drive/drivetypes.h vice/src/drive/drive.h vice/src/mos6510.h \
 vice/src/r65c02.h vice/src/interrupt.h vice/src/log.h \
 vice/src/joyport/joyport.h vice/src/joyport/joystick.h \
 vice/src/keyboard.h vice/src/log.h vice/src/machine.h vice/src/maincpu.h \
 vice/src/mainlock.h vice/src/vsyncapi.h vice/src/userport/userport.h \
 vice/src/vicii.h vice/src/joyport/mouse.h
