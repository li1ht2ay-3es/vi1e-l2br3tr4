vice/src/c128/c128mmu.o: vice/src/c128/c128mmu.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/c128/c128.h \
 vice/src/c128/c128-resources.h vice/src/c128/c128fastiec.h \
 vice/src/types.h vice/src/vice.h vice/src/c128/c128mem.h vice/src/mem.h \
 vice/src/types.h vice/src/c128/c128memrom.h vice/src/c128/c128mmu.h \
 vice/src/c64/c64cart.h vice/src/c64/cart/expert.h vice/src/cmdline.h \
 vice/src/c128/functionrom.h vice/src/interrupt.h vice/src/debug.h \
 vice/src/log.h vice/src/keyboard.h vice/src/log.h vice/src/maincpu.h \
 vice/src/mainlock.h vice/src/vsyncapi.h vice/src/monitor.h \
 vice/src/monitor/asm.h vice/src/resources.h vice/src/c64/cart/reu.h \
 vice/src/vdc/vdc.h vice/src/vicii.h vice/src/c128/z80.h \
 vice/src/c128/z80mem.h
