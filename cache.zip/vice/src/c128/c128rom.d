vice/src/c128/c128rom.o: vice/src/c128/c128rom.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/c128/c128.h \
 vice/src/c128/c128mem.h vice/src/mem.h vice/src/types.h vice/src/vice.h \
 vice/src/types.h vice/src/c128/c128memrom.h vice/src/c128/c128rom.h \
 vice/src/c64/c64memrom.h vice/src/c64/c64rom.h vice/src/log.h \
 vice/src/resources.h vice/src/sysfile.h vice/src/util.h \
 vice/src/c128/z80mem.h include/embedded/c128kernal.h \
 include/embedded/c128kernalde.h include/embedded/c128kernalfi.h \
 include/embedded/c128kernalfr.h include/embedded/c128kernalit.h \
 include/embedded/c128kernalno.h include/embedded/c128kernalse.h \
 include/embedded/c128kernalch.h include/embedded/c128chargde.h \
 include/embedded/c128chargen.h include/embedded/c128chargfr.h \
 include/embedded/c128chargse.h include/embedded/c128chargch.h \
 include/embedded/c128chargno.h
