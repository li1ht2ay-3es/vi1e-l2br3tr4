vice/src/c128/c128cpu.o: vice/src/c128/c128cpu.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/clkguard.h \
 vice/src/types.h vice/src/vice.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/vsyncapi.h vice/src/mem.h vice/src/vicii.h \
 vice/src/vicii/viciitypes.h vice/src/raster/raster.h vice/src/types.h \
 vice/src/c128/z80.h vice/src/c128/../maincpu.c vice/src/c128/../vice.h \
 vice/src/c128/../6510core.h vice/src/c128/../alarm.h \
 vice/src/c128/../types.h retrodep/archdep.h vice/src/archapi.h \
 vice/src/c128/../clkguard.h vice/src/c128/../debug.h \
 vice/src/c128/../interrupt.h vice/src/c128/../log.h \
 vice/src/c128/../machine.h vice/src/c128/../maincpu.h \
 vice/src/c128/../mainlock.h vice/src/c128/../mem.h \
 vice/src/c128/../monitor.h vice/src/c128/../monitor/asm.h \
 vice/src/c128/../mos6510.h vice/src/c128/../h6809regs.h \
 vice/src/c128/../snapshot.h retrodep/snapshot_stream.h \
 vice/src/c128/../traps.h vice/src/c128/../6510core.c
