vice/src/c128/c128mem.o: vice/src/c128/c128mem.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h \
 vice/src/c128/c128-resources.h vice/src/c128/c128.h \
 vice/src/c128/c128mem.h vice/src/mem.h vice/src/types.h vice/src/vice.h \
 vice/src/types.h vice/src/c128/c128meminit.h \
 vice/src/c128/c128memlimit.h vice/src/c128/c128memrom.h \
 vice/src/c128/c128mmu.h vice/src/c64/c64cart.h \
 vice/src/c64/cart/expert.h vice/src/c64/c64cia.h \
 vice/src/c64/c64meminit.h vice/src/c64/c64memrom.h vice/src/c64/c64pla.h \
 vice/src/cartio.h vice/src/cartridge.h vice/src/sound.h vice/src/cia.h \
 vice/src/clkguard.h vice/src/c128/functionrom.h \
 vice/src/c64/cart/georam.h vice/src/keyboard.h vice/src/log.h \
 vice/src/machine.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/vsyncapi.h vice/src/monitor.h vice/src/monitor/asm.h \
 vice/src/ram.h vice/src/c64/cart/reu.h vice/src/sid/sid.h \
 vice/src/sound.h vice/src/sid/sid-resources.h vice/src/vdc/vdc-mem.h \
 vice/src/vdc/vdc.h vice/src/vdc/vdctypes.h vice/src/raster/raster.h \
 vice/src/vicii/vicii-mem.h vice/src/vicii/vicii-phi1.h vice/src/vicii.h \
 vice/src/c128/z80mem.h
