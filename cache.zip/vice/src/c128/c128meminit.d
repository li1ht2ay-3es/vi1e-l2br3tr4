vice/src/c128/c128meminit.o: vice/src/c128/c128meminit.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/c128/c128mem.h \
 vice/src/mem.h vice/src/types.h vice/src/vice.h vice/src/types.h \
 vice/src/c128/c128meminit.h vice/src/c128/c128memrom.h \
 vice/src/c128/c128mmu.h vice/src/c64/c64cia.h vice/src/cartio.h \
 vice/src/c128/functionrom.h vice/src/sid/sid.h vice/src/sound.h \
 vice/src/vdc/vdc-mem.h vice/src/vicii/vicii-mem.h
