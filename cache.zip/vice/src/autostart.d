vice/src/autostart.o: vice/src/autostart.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/archdep.h \
 vice/src/archapi.h vice/src/autostart.h vice/src/types.h \
 vice/src/autostart-prg.h vice/src/log.h vice/src/fileio.h \
 vice/src/attach.h vice/src/cartridge.h vice/src/sound.h \
 vice/src/charset.h vice/src/cmdline.h vice/src/datasette/datasette.h \
 vice/src/types.h vice/src/diskimage.h vice/src/drive/drive.h \
 vice/src/rtc/ds1216e.h vice/src/snapshot.h retrodep/snapshot_stream.h \
 vice/src/lib/p64/p64.h vice/src/lib/p64/p64config.h vice/src/lib.h \
 vice/src/vice.h vice/src/debug.h vice/src/types.h \
 vice/src/drive/drivetypes.h vice/src/drive/drive.h vice/src/mos6510.h \
 vice/src/r65c02.h vice/src/drive/driveimage.h vice/src/fsdevice.h \
 vice/src/fsdevice/fsdevice-filename.h vice/src/vdrive/vdrive.h \
 vice/src/vdrive/vdrive-dir.h vice/src/cbmdos.h vice/src/imagecontents.h \
 vice/src/imagecontents/tapecontents.h \
 vice/src/imagecontents/diskcontents.h vice/src/initcmdline.h \
 vice/src/interrupt.h vice/src/debug.h vice/src/ioutil.h \
 vice/src/kbdbuf.h vice/src/lib.h vice/src/machine-bus.h \
 vice/src/machine.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/vsyncapi.h vice/src/mem.h vice/src/monitor.h \
 vice/src/monitor/asm.h vice/src/monitor/mon_breakpoint.h \
 vice/src/monitor/montypes.h vice/src/monitor.h vice/src/network.h \
 vice/src/resources.h vice/src/snapshot.h vice/src/tape.h \
 vice/src/tapeport/tapecart.h vice/src/tapeport/tapeport.h \
 vice/src/uiapi.h vice/src/util.h vice/src/vdrive/vdrive-bam.h \
 vice/src/vice-event.h vice/src/vsync.h vice/src/keyboard.h \
 libretro/libretro-glue.h libretro/libretro-dc.h deps/libz/zlib.h \
 deps/libz/zconf.h deps/libz/unzip.h deps/libz/zlib.h deps/libz/ioapi.h \
 deps/7zip/7z.h deps/7zip/7zTypes.h deps/7zip/7zBuf.h deps/7zip/7zCrc.h \
 deps/7zip/7zFile.h deps/7zip/7zTypes.h
