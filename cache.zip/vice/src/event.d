vice/src/event.o: vice/src/event.c vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/alarm.h \
 vice/src/types.h retrodep/archdep.h vice/src/archapi.h vice/src/attach.h \
 vice/src/autostart.h vice/src/clkguard.h vice/src/cmdline.h \
 vice/src/crc32.h vice/src/datasette/datasette.h vice/src/types.h \
 vice/src/debug.h vice/src/interrupt.h vice/src/log.h \
 vice/src/joyport/joystick.h vice/src/keyboard.h vice/src/lib.h \
 vice/src/machine.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/vsyncapi.h vice/src/network.h vice/src/resources.h \
 vice/src/snapshot.h retrodep/snapshot_stream.h vice/src/tape.h \
 vice/src/uiapi.h vice/src/util.h vice/src/version.h \
 vice/src/vice-event.h
