vice/src/crtc/crtc-snapshot.o: vice/src/crtc/crtc-snapshot.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/crtc/crtc-mem.h \
 vice/src/types.h vice/src/vice.h vice/src/crtc/crtc.h \
 vice/src/crtc/crtctypes.h vice/src/raster/raster.h vice/src/log.h \
 vice/src/maincpu.h vice/src/mainlock.h vice/src/types.h \
 vice/src/vsyncapi.h vice/src/snapshot.h retrodep/snapshot_stream.h
