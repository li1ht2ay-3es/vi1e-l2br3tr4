vice/src/residfp/builders/residfp-builder/residfp/Dac.o: \
 vice/src/residfp/builders/residfp-builder/residfp/Dac.cpp \
 vice/src/residfp/builders/residfp-builder/residfp/Dac.h \
 vice/src/residfp/builders/residfp-builder/residfp/siddefs-fp.h
