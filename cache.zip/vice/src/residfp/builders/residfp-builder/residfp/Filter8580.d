vice/src/residfp/builders/residfp-builder/residfp/Filter8580.o: \
 vice/src/residfp/builders/residfp-builder/residfp/Filter8580.cpp \
 vice/src/residfp/builders/residfp-builder/residfp/Filter8580.h \
 vice/src/residfp/builders/residfp-builder/residfp/../../../sysincludes.h \
 vice/src/residfp/builders/residfp-builder/residfp/siddefs-fp.h \
 vice/src/residfp/builders/residfp-builder/residfp/Filter.h \
 vice/src/residfp/builders/residfp-builder/residfp/../../../sidcxx11.h \
 include/config.h libretro-common/include/retro_endianness.h \
 libretro-common/include/retro_inline.h \
 vice/src/residfp/builders/residfp-builder/residfp/FilterModelConfig8580.h \
 vice/src/residfp/builders/residfp-builder/residfp/Spline.h \
 vice/src/residfp/sidcxx11.h \
 vice/src/residfp/builders/residfp-builder/residfp/Integrator8580.h
