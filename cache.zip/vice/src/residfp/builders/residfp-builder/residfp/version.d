vice/src/residfp/builders/residfp-builder/residfp/version.o: \
 vice/src/residfp/builders/residfp-builder/residfp/version.cc \
 vice/src/residfp/builders/residfp-builder/residfp/siddefs-fp.h
