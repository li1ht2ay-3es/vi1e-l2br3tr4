vice/src/residfp/builders/residfp-builder/residfp/ExternalFilter.o: \
 vice/src/residfp/builders/residfp-builder/residfp/ExternalFilter.cpp \
 vice/src/residfp/builders/residfp-builder/residfp/ExternalFilter.h \
 vice/src/residfp/builders/residfp-builder/residfp/siddefs-fp.h
