vice/src/residfp/builders/residfp-builder/residfp/resample/SincResampler.o: \
 vice/src/residfp/builders/residfp-builder/residfp/resample/SincResampler.cpp \
 vice/src/residfp/builders/residfp-builder/residfp/resample/SincResampler.h \
 vice/src/residfp/builders/residfp-builder/residfp/../../../sysincludes.h \
 vice/src/residfp/builders/residfp-builder/residfp/resample/Resampler.h \
 vice/src/residfp/builders/residfp-builder/residfp/resample/../array.h \
 vice/src/residfp/sidcxx11.h include/config.h \
 libretro-common/include/retro_endianness.h \
 libretro-common/include/retro_inline.h \
 vice/src/residfp/builders/residfp-builder/residfp/siddefs-fp.h
