vice/src/residfp/builders/residfp-builder/residfp/Spline.o: \
 vice/src/residfp/builders/residfp-builder/residfp/Spline.cpp \
 vice/src/residfp/builders/residfp-builder/residfp/Spline.h \
 vice/src/residfp/builders/residfp-builder/residfp/../../../sysincludes.h
