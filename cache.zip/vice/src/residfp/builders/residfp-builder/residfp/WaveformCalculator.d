vice/src/residfp/builders/residfp-builder/residfp/WaveformCalculator.o: \
 vice/src/residfp/builders/residfp-builder/residfp/WaveformCalculator.cpp \
 vice/src/residfp/builders/residfp-builder/residfp/WaveformCalculator.h \
 vice/src/residfp/builders/residfp-builder/residfp/../../../sysincludes.h \
 vice/src/residfp/builders/residfp-builder/residfp/siddefs-fp.h \
 vice/src/residfp/builders/residfp-builder/residfp/array.h
