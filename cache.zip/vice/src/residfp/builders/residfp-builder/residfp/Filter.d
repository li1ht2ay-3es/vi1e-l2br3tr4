vice/src/residfp/builders/residfp-builder/residfp/Filter.o: \
 vice/src/residfp/builders/residfp-builder/residfp/Filter.cpp \
 vice/src/residfp/builders/residfp-builder/residfp/Filter.h \
 vice/src/residfp/builders/residfp-builder/residfp/../../../sidcxx11.h \
 include/config.h libretro-common/include/retro_endianness.h \
 libretro-common/include/retro_inline.h
