vice/src/residfp/builders/residfp-builder/residfp/OpAmp.o: \
 vice/src/residfp/builders/residfp-builder/residfp/OpAmp.cpp \
 vice/src/residfp/builders/residfp-builder/residfp/OpAmp.h \
 vice/src/residfp/builders/residfp-builder/residfp/../../../sysincludes.h \
 vice/src/residfp/builders/residfp-builder/residfp/Spline.h \
 vice/src/residfp/sidcxx11.h include/config.h \
 libretro-common/include/retro_endianness.h \
 libretro-common/include/retro_inline.h \
 vice/src/residfp/builders/residfp-builder/residfp/siddefs-fp.h
