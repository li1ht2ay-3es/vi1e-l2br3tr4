vice/src/residfp/builders/residfp-builder/residfp/WaveformGenerator.o: \
 vice/src/residfp/builders/residfp-builder/residfp/WaveformGenerator.cpp \
 vice/src/residfp/builders/residfp-builder/residfp/WaveformGenerator.h \
 vice/src/residfp/builders/residfp-builder/residfp/siddefs-fp.h \
 vice/src/residfp/builders/residfp-builder/residfp/array.h \
 vice/src/residfp/sidcxx11.h include/config.h \
 libretro-common/include/retro_endianness.h \
 libretro-common/include/retro_inline.h \
 vice/src/residfp/builders/residfp-builder/residfp/Dac.h
