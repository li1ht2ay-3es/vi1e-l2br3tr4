vice/src/residfp/builders/residfp-builder/residfp/Integrator8580.o: \
 vice/src/residfp/builders/residfp-builder/residfp/Integrator8580.cpp \
 vice/src/residfp/builders/residfp-builder/residfp/Integrator8580.h \
 vice/src/residfp/builders/residfp-builder/residfp/../../../sysincludes.h \
 vice/src/residfp/builders/residfp-builder/residfp/siddefs-fp.h
