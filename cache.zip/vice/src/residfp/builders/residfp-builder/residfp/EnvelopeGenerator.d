vice/src/residfp/builders/residfp-builder/residfp/EnvelopeGenerator.o: \
 vice/src/residfp/builders/residfp-builder/residfp/EnvelopeGenerator.cpp \
 vice/src/residfp/builders/residfp-builder/residfp/EnvelopeGenerator.h \
 vice/src/residfp/builders/residfp-builder/residfp/siddefs-fp.h \
 vice/src/residfp/builders/residfp-builder/residfp/Dac.h
