vice/src/drive/drivemem.o: vice/src/drive/drivemem.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/cartio.h \
 vice/src/types.h vice/src/vice.h vice/src/drive/iec/ciad.h \
 vice/src/types.h vice/src/drive/drive.h vice/src/rtc/ds1216e.h \
 vice/src/snapshot.h retrodep/snapshot_stream.h vice/src/lib/p64/p64.h \
 vice/src/lib/p64/p64config.h vice/src/lib.h vice/src/debug.h \
 vice/src/drive/drivetypes.h vice/src/mos6510.h vice/src/r65c02.h \
 vice/src/drive/drivemem.h vice/src/drive/driverom.h \
 vice/src/rtc/ds1216e.h vice/src/log.h vice/src/machine-drive.h \
 vice/src/mem.h vice/src/monitor.h vice/src/monitor/asm.h \
 vice/src/drive/ieee/riotd.h vice/src/drive/tcbm/tpid.h \
 vice/src/drive/iec/via1d1541.h vice/src/drive/iec/via4000.h \
 vice/src/drive/viad.h vice/src/drive/iec/cmdhd.h vice/src/diskimage.h \
 vice/src/rtc/rtc-72421.h vice/src/alarm.h vice/src/via.h \
 vice/src/core/scsi.h vice/src/core/i8255a.h
