vice/src/drive/iec/iec-cmdline-options.o: \
 vice/src/drive/iec/iec-cmdline-options.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/cmdline.h \
 vice/src/drive/drive.h vice/src/types.h vice/src/vice.h \
 vice/src/rtc/ds1216e.h vice/src/snapshot.h retrodep/snapshot_stream.h \
 vice/src/lib/p64/p64.h vice/src/lib/p64/p64config.h vice/src/lib.h \
 vice/src/debug.h vice/src/types.h vice/src/drive/drivetypes.h \
 vice/src/drive/drive.h vice/src/mos6510.h vice/src/r65c02.h \
 vice/src/drive/iec/iec-cmdline-options.h
