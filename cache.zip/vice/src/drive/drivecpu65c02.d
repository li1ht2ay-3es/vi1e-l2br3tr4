vice/src/drive/drivecpu65c02.o: vice/src/drive/drivecpu65c02.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/6510core.h \
 vice/src/alarm.h vice/src/types.h vice/src/vice.h vice/src/clkguard.h \
 vice/src/debug.h vice/src/drive/drive.h vice/src/types.h \
 vice/src/rtc/ds1216e.h vice/src/snapshot.h retrodep/snapshot_stream.h \
 vice/src/lib/p64/p64.h vice/src/lib/p64/p64config.h vice/src/lib.h \
 vice/src/debug.h vice/src/drive/drivetypes.h vice/src/mos6510.h \
 vice/src/r65c02.h vice/src/drive/drivecpu65c02.h \
 vice/src/drive/drive-check.h vice/src/drive/drivemem.h \
 vice/src/interrupt.h vice/src/log.h vice/src/log.h \
 vice/src/machine-drive.h vice/src/machine.h vice/src/mem.h \
 vice/src/monitor.h vice/src/monitor/asm.h vice/src/drive/rotation.h \
 vice/src/65c02core.c vice/src/traps.h vice/src/mem.h
