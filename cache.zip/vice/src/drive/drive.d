vice/src/drive/drive.o: vice/src/drive/drive.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/attach.h \
 vice/src/types.h vice/src/vice.h vice/src/diskconstants.h \
 vice/src/diskimage.h vice/src/drive/drive-check.h \
 vice/src/drive/drive-overflow.h vice/src/drive/drive.h vice/src/types.h \
 vice/src/rtc/ds1216e.h vice/src/snapshot.h retrodep/snapshot_stream.h \
 vice/src/lib/p64/p64.h vice/src/lib/p64/p64config.h vice/src/lib.h \
 vice/src/debug.h vice/src/drive/drivetypes.h vice/src/mos6510.h \
 vice/src/r65c02.h vice/src/drive/drivecpu.h \
 vice/src/drive/drivecpu65c02.h vice/src/drive/driveimage.h \
 vice/src/drive/drivesync.h vice/src/drive/driverom.h vice/src/gcr.h \
 vice/src/cbmdos.h vice/src/iecbus.h vice/src/iecdrive.h vice/src/log.h \
 vice/src/machine-drive.h vice/src/machine.h vice/src/maincpu.h \
 vice/src/mainlock.h vice/src/vsyncapi.h vice/src/resources.h \
 vice/src/drive/rotation.h vice/src/uiapi.h vice/src/rtc/ds1216e.h \
 vice/src/drive/drive-sound.h vice/src/monitor.h vice/src/monitor/asm.h \
 vice/src/vsync.h libretro/libretro-core.h libretro/libretro-glue.h \
 libretro/libretro-dc.h deps/libz/zlib.h deps/libz/zconf.h \
 deps/libz/unzip.h deps/libz/zlib.h deps/libz/ioapi.h deps/7zip/7z.h \
 deps/7zip/7zTypes.h deps/7zip/7zBuf.h deps/7zip/7zCrc.h \
 deps/7zip/7zFile.h deps/7zip/7zTypes.h \
 libretro-common/include/string/stdstring.h \
 libretro-common/include/compat/strl.h \
 libretro-common/include/file/file_path.h \
 libretro-common/include/encodings/utf.h \
 libretro-common/include/compat/strcasestr.h vice/src/cbm2/cbm2.h \
 vice/src/mem.h vice/src/cbm2/cbm2model.h
