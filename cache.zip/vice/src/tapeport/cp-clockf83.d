vice/src/tapeport/cp-clockf83.o: vice/src/tapeport/cp-clockf83.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/cmdline.h \
 vice/src/rtc/pcf8583.h vice/src/snapshot.h retrodep/snapshot_stream.h \
 vice/src/types.h vice/src/vice.h vice/src/resources.h \
 vice/src/tapeport/tapeport.h vice/src/tapeport/cp-clockf83.h
