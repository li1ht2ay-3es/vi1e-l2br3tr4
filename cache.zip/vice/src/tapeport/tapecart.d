vice/src/tapeport/tapecart.o: vice/src/tapeport/tapecart.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/alarm.h \
 vice/src/types.h vice/src/vice.h retrodep/archdep.h vice/src/archapi.h \
 vice/src/cmdline.h vice/src/crc32.h vice/src/lib.h vice/src/debug.h \
 vice/src/log.h vice/src/machine.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/vsyncapi.h vice/src/resources.h vice/src/snapshot.h \
 retrodep/snapshot_stream.h vice/src/types.h vice/src/tapeport/tapeport.h \
 vice/src/tapeport/tapecart.h vice/src/tapeport/tapecart-loader.h
