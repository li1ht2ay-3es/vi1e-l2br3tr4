vice/src/tape/tape-snapshot.o: vice/src/tape/tape-snapshot.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/archdep.h \
 vice/src/archapi.h vice/src/datasette/datasette.h vice/src/types.h \
 vice/src/vice.h vice/src/lib.h vice/src/debug.h vice/src/types.h \
 vice/src/log.h vice/src/resources.h vice/src/snapshot.h \
 retrodep/snapshot_stream.h vice/src/tape/t64.h vice/src/tap.h \
 vice/src/tape/tape-snapshot.h vice/src/tape.h
