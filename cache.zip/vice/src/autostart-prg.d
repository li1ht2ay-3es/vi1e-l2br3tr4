vice/src/autostart-prg.o: vice/src/autostart-prg.c retrodep/archdep.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h vice/src/archapi.h vice/src/attach.h \
 vice/src/types.h vice/src/vice.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/autostart-prg.h \
 vice/src/log.h vice/src/fileio.h vice/src/fsdevice.h vice/src/lib.h \
 vice/src/debug.h vice/src/machine.h vice/src/mem.h vice/src/resources.h \
 vice/src/util.h vice/src/diskimage.h vice/src/vdrive/vdrive.h \
 vice/src/types.h vice/src/vdrive/vdrive-dir.h vice/src/cbmdos.h \
 vice/src/types.h vice/src/vdrive/vdrive-iec.h \
 vice/src/vdrive/vdrive-internal.h vice/src/drive/drive.h \
 vice/src/rtc/ds1216e.h vice/src/snapshot.h retrodep/snapshot_stream.h \
 vice/src/lib/p64/p64.h vice/src/lib/p64/p64config.h vice/src/lib.h \
 vice/src/drive/drivetypes.h vice/src/drive/drive.h vice/src/mos6510.h \
 vice/src/r65c02.h
