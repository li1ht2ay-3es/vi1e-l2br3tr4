vice/src/core/viacore.o: vice/src/core/viacore.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/alarm.h \
 vice/src/types.h vice/src/vice.h vice/src/clkguard.h \
 vice/src/interrupt.h vice/src/debug.h vice/src/log.h vice/src/lib.h \
 vice/src/log.h vice/src/monitor.h vice/src/monitor/asm.h \
 vice/src/types.h vice/src/snapshot.h retrodep/snapshot_stream.h \
 vice/src/via.h
