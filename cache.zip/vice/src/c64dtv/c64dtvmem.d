vice/src/c64dtv/c64dtvmem.o: vice/src/c64dtv/c64dtvmem.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/c64dtv/c64dtvmem.h \
 vice/src/types.h vice/src/vice.h vice/src/c64dtv/c64dtvblitter.h \
 vice/src/c64dtv/c64dtvcpu.h vice/src/c64dtv/c64dtvdma.h \
 vice/src/c64dtv/c64dtvflash.h vice/src/cartio.h vice/src/types.h \
 vice/src/cia.h vice/src/cmdline.h vice/src/c64dtv/debugcart.h \
 vice/src/lib.h vice/src/debug.h vice/src/log.h vice/src/util.h \
 vice/src/resources.h vice/src/mos6510dtv.h vice/src/interrupt.h \
 vice/src/log.h vice/src/alarm.h vice/src/c64dtv/hummeradc.h \
 vice/src/ps2mouse.h vice/src/c64/c64.h vice/src/c64/c64-resources.h \
 vice/src/c64/c64cia.h vice/src/c64/c64mem.h vice/src/mem.h \
 vice/src/c64dtv/c64dtvmeminit.h vice/src/c64/c64memrom.h \
 vice/src/c64/c64pla.h vice/src/machine.h vice/src/maincpu.h \
 vice/src/mainlock.h vice/src/vsyncapi.h vice/src/monitor.h \
 vice/src/monitor/asm.h vice/src/ram.h vice/src/sid/sid.h \
 vice/src/sound.h vice/src/vicii/vicii-mem.h vice/src/vicii/vicii-phi1.h \
 vice/src/vicii.h vice/src/vicii/viciitypes.h vice/src/raster/raster.h \
 include/embedded/c64chargen.h
