vice/src/c64dtv/flash-trap.o: vice/src/c64dtv/flash-trap.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/archdep.h \
 vice/src/archapi.h vice/src/cmdline.h vice/src/fileio.h vice/src/types.h \
 vice/src/vice.h vice/src/c64dtv/flash-trap.h vice/src/traps.h \
 vice/src/mem.h vice/src/types.h vice/src/lib.h vice/src/debug.h \
 vice/src/log.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/vsyncapi.h vice/src/mem.h vice/src/util.h vice/src/resources.h
