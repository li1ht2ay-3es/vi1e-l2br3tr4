vice/src/c64dtv/c64dtvdma.o: vice/src/c64dtv/c64dtvdma.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/c64/c64mem.h \
 vice/src/mem.h vice/src/types.h vice/src/vice.h vice/src/types.h \
 vice/src/c64dtv/c64dtvmem.h vice/src/c64dtv/c64dtvflash.h \
 vice/src/c64dtv/c64dtvdma.h vice/src/cmdline.h vice/src/debug.h \
 vice/src/lib.h vice/src/debug.h vice/src/log.h vice/src/util.h \
 vice/src/resources.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/vsyncapi.h vice/src/interrupt.h vice/src/log.h \
 vice/src/snapshot.h retrodep/snapshot_stream.h
