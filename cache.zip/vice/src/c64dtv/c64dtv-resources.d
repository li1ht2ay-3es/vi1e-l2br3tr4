vice/src/c64dtv/c64dtv-resources.o: vice/src/c64dtv/c64dtv-resources.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h \
 vice/src/c64dtv/c64dtv-resources.h vice/src/c64/c64cart.h \
 vice/src/types.h vice/src/vice.h vice/src/c64/cart/expert.h \
 vice/src/c64/c64rom.h vice/src/cartridge.h vice/src/types.h \
 vice/src/sound.h vice/src/c64dtv/hummeradc.h vice/src/ps2mouse.h \
 retrodep/kbd.h vice/src/keyboard.h vice/src/lib.h vice/src/debug.h \
 vice/src/machine.h vice/src/resources.h vice/src/sid/sid-resources.h \
 vice/src/util.h vice/src/vicii/vicii-resources.h vice/src/vicii.h
