vice/src/c64dtv/c64dtvcpu.o: vice/src/c64dtv/c64dtvcpu.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/alarm.h \
 vice/src/types.h vice/src/vice.h vice/src/c64/c64mem.h vice/src/mem.h \
 vice/src/types.h vice/src/c64dtv/c64dtvblitter.h \
 vice/src/c64dtv/c64dtvcpu.h vice/src/c64dtv/c64dtvdma.h \
 vice/src/monitor.h vice/src/monitor/asm.h vice/src/c64dtv/../maincpu.c \
 vice/src/c64dtv/../vice.h vice/src/c64dtv/../6510core.h \
 vice/src/c64dtv/../alarm.h retrodep/archdep.h vice/src/archapi.h \
 vice/src/c64dtv/../clkguard.h vice/src/c64dtv/../types.h \
 vice/src/c64dtv/../debug.h vice/src/c64dtv/../interrupt.h \
 vice/src/c64dtv/../log.h vice/src/c64dtv/../machine.h \
 vice/src/c64dtv/../maincpu.h vice/src/c64dtv/../mainlock.h \
 vice/src/c64dtv/../vsyncapi.h vice/src/c64dtv/../mem.h \
 vice/src/c64dtv/../monitor.h vice/src/c64dtv/../mos6510dtv.h \
 vice/src/c64dtv/../h6809regs.h vice/src/c64dtv/../snapshot.h \
 retrodep/snapshot_stream.h vice/src/c64dtv/../traps.h \
 vice/src/c64dtv/../6510core.c
