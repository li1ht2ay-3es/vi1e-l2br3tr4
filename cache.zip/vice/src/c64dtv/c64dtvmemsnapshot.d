vice/src/c64dtv/c64dtvmemsnapshot.o: vice/src/c64dtv/c64dtvmemsnapshot.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h \
 vice/src/c64dtv/c64dtv-resources.h vice/src/c64/c64cart.h \
 vice/src/types.h vice/src/vice.h vice/src/c64/cart/expert.h \
 vice/src/c64/c64mem.h vice/src/mem.h vice/src/types.h \
 vice/src/c64/c64memrom.h vice/src/c64/c64memsnapshot.h \
 vice/src/c64/c64pla.h vice/src/c64/c64rom.h vice/src/log.h \
 vice/src/resources.h vice/src/snapshot.h retrodep/snapshot_stream.h \
 vice/src/uiapi.h vice/src/c64dtv/c64dtvmem.h \
 vice/src/c64dtv/c64dtvflash.h vice/src/c64dtv/c64dtvmemsnapshot.h \
 vice/src/c64dtv/hummeradc.h
