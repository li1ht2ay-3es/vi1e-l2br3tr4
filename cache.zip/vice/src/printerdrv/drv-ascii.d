vice/src/printerdrv/drv-ascii.o: vice/src/printerdrv/drv-ascii.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/archdep.h \
 vice/src/archapi.h vice/src/charset.h vice/src/types.h vice/src/vice.h \
 vice/src/printerdrv/driver-select.h vice/src/types.h \
 vice/src/printerdrv/drv-ascii.h vice/src/log.h \
 vice/src/printerdrv/output-select.h vice/src/printerdrv/output.h
