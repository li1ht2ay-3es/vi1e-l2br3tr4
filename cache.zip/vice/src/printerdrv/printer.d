vice/src/printerdrv/printer.o: vice/src/printerdrv/printer.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h \
 vice/src/printerdrv/driver-select.h vice/src/types.h vice/src/vice.h \
 vice/src/printerdrv/drv-ascii.h vice/src/printerdrv/drv-mps803.h \
 vice/src/printerdrv/drv-nl10.h vice/src/printerdrv/drv-1520.h \
 vice/src/printerdrv/drv-raw.h vice/src/printerdrv/interface-serial.h \
 vice/src/printerdrv/interface-userport.h vice/src/machine-printer.h \
 vice/src/printerdrv/output-graphics.h \
 vice/src/printerdrv/output-select.h vice/src/printerdrv/output-text.h \
 vice/src/printer.h vice/src/types.h
