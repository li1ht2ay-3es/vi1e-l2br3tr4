vice/src/init.o: vice/src/init.c vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/archdep.h \
 vice/src/archapi.h vice/src/attach.h vice/src/types.h vice/src/cmdline.h \
 vice/src/console.h vice/src/debug.h vice/src/drive/drive.h \
 vice/src/types.h vice/src/rtc/ds1216e.h vice/src/snapshot.h \
 retrodep/snapshot_stream.h vice/src/lib/p64/p64.h \
 vice/src/lib/p64/p64config.h vice/src/lib.h vice/src/vice.h \
 vice/src/debug.h vice/src/drive/drivetypes.h vice/src/drive/drive.h \
 vice/src/mos6510.h vice/src/types.h vice/src/r65c02.h \
 vice/src/initcmdline.h vice/src/keyboard.h vice/src/log.h \
 vice/src/machine-bus.h vice/src/machine-video.h vice/src/machine.h \
 vice/src/maincpu.h vice/src/mainlock.h vice/src/vsyncapi.h \
 vice/src/monitor.h vice/src/monitor/asm.h vice/src/palette.h \
 vice/src/ram.h vice/src/resources.h vice/src/romset.h \
 vice/src/screenshot.h vice/src/viewport.h vice/src/signals.h \
 vice/src/sound.h vice/src/sysfile.h vice/src/uiapi.h \
 vice/src/vdrive/vdrive.h vice/src/vdrive/vdrive-dir.h vice/src/cbmdos.h \
 vice/src/video.h vice/src/vsync.h vice/src/init.h
