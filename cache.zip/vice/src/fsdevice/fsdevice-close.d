vice/src/fsdevice/fsdevice-close.o: vice/src/fsdevice/fsdevice-close.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/cbmdos.h \
 vice/src/types.h vice/src/vice.h vice/src/fileio.h \
 vice/src/fsdevice/fsdevice-close.h vice/src/types.h \
 vice/src/fsdevice/fsdevice-read.h vice/src/fsdevice/fsdevicetypes.h \
 vice/src/ioutil.h vice/src/tape.h vice/src/vdrive/vdrive.h \
 vice/src/vdrive/vdrive-dir.h
