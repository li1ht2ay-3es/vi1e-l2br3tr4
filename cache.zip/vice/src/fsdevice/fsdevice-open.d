vice/src/fsdevice/fsdevice-open.o: vice/src/fsdevice/fsdevice-open.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/archdep.h \
 vice/src/archapi.h vice/src/cbmdos.h vice/src/types.h vice/src/vice.h \
 vice/src/charset.h vice/src/fileio.h \
 vice/src/fsdevice/fsdevice-filename.h vice/src/vdrive/vdrive.h \
 vice/src/types.h vice/src/vdrive/vdrive-dir.h \
 vice/src/fsdevice/fsdevice-open.h vice/src/fsdevice/fsdevice-read.h \
 vice/src/fsdevice/fsdevice-resources.h \
 vice/src/fsdevice/fsdevice-write.h vice/src/fsdevice/fsdevicetypes.h \
 vice/src/ioutil.h vice/src/lib.h vice/src/debug.h vice/src/log.h \
 vice/src/resources.h vice/src/tape.h vice/src/vdrive/vdrive-command.h \
 vice/src/util.h
