vice/src/viciisc/vicii-mem.o: vice/src/viciisc/vicii-mem.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/debug.h \
 vice/src/types.h vice/src/vice.h vice/src/types.h \
 vice/src/viciisc/vicii-chip-model.h vice/src/viciisc/vicii-draw-cycle.h \
 vice/src/viciisc/vicii-fetch.h vice/src/viciisc/vicii-irq.h \
 vice/src/viciisc/vicii-resources.h vice/src/viciisc/vicii-mem.h \
 vice/src/vicii.h vice/src/viciisc/viciitypes.h vice/src/raster/raster.h
