vice/src/viciisc/vicii-fetch.o: vice/src/viciisc/vicii-fetch.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/c64/c64cart.h \
 vice/src/types.h vice/src/vice.h vice/src/c64/cart/expert.h \
 vice/src/c64/cart/c64cartmem.h vice/src/debug.h vice/src/types.h \
 vice/src/maincpu.h vice/src/mainlock.h vice/src/vsyncapi.h \
 vice/src/mem.h vice/src/viciisc/vicii-chip-model.h \
 vice/src/viciisc/vicii-fetch.h vice/src/viciisc/viciitypes.h \
 vice/src/raster/raster.h
