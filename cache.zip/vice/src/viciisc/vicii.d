vice/src/viciisc/vicii.o: vice/src/viciisc/vicii.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/videoarch.h \
 vice/src/c64/c64cart.h vice/src/types.h vice/src/vice.h \
 vice/src/c64/cart/expert.h vice/src/c64/cart/c64cartmem.h \
 vice/src/clkguard.h vice/src/types.h vice/src/lib.h vice/src/debug.h \
 vice/src/log.h vice/src/machine.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/vsyncapi.h vice/src/mem.h vice/src/monitor.h \
 vice/src/monitor/asm.h vice/src/raster/raster-line.h \
 vice/src/raster/raster-modes.h vice/src/raster/raster-cache.h \
 vice/src/raster/raster-sprite-cache.h vice/src/resources.h \
 vice/src/screenshot.h vice/src/viewport.h \
 vice/src/viciisc/vicii-chip-model.h \
 vice/src/viciisc/vicii-cmdline-options.h vice/src/viciisc/vicii-color.h \
 vice/src/viciisc/vicii-cycle.h vice/src/viciisc/vicii-draw.h \
 vice/src/viciisc/vicii-draw-cycle.h vice/src/viciisc/vicii-fetch.h \
 vice/src/viciisc/vicii-irq.h vice/src/viciisc/vicii-mem.h \
 vice/src/viciisc/vicii-resources.h vice/src/viciisc/vicii-timing.h \
 vice/src/vicii.h vice/src/viciisc/viciitypes.h vice/src/raster/raster.h \
 vice/src/vsync.h vice/src/video.h vice/src/viewport.h
