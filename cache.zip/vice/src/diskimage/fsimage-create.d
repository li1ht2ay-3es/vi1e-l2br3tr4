vice/src/diskimage/fsimage-create.o: vice/src/diskimage/fsimage-create.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/archdep.h \
 vice/src/archapi.h vice/src/diskconstants.h vice/src/diskimage.h \
 vice/src/types.h vice/src/vice.h vice/src/diskimage/fsimage-create.h \
 vice/src/diskimage/fsimage.h vice/src/types.h vice/src/gcr.h \
 vice/src/cbmdos.h vice/src/lib.h vice/src/debug.h vice/src/log.h \
 vice/src/util.h vice/src/diskimage/x64.h vice/src/lib/p64/p64.h \
 vice/src/lib/p64/p64config.h vice/src/cbmdos.h
