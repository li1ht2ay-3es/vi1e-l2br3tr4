vice/src/video/video-resources.o: vice/src/video/video-resources.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/videoarch.h \
 vice/src/lib.h vice/src/vice.h vice/src/debug.h vice/src/types.h \
 vice/src/log.h vice/src/machine.h vice/src/resources.h \
 vice/src/video/video-color.h vice/src/palette.h vice/src/types.h \
 vice/src/video.h vice/src/viewport.h vice/src/util.h
