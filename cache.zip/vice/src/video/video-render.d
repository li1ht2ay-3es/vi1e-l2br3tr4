vice/src/video/video-render.o: vice/src/video/video-render.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/log.h \
 vice/src/video/render1x1.h vice/src/types.h vice/src/vice.h \
 vice/src/video.h vice/src/types.h vice/src/video/render1x1pal.h \
 vice/src/video/render1x1ntsc.h vice/src/video/render1x2crt.h \
 vice/src/viewport.h vice/src/video/render2x2crt.h \
 vice/src/video/render2x2ntsc.h vice/src/video/render2x2pal.h \
 vice/src/video/render2x4crt.h vice/src/video/video-render.h \
 vice/src/video/video-sound.h
