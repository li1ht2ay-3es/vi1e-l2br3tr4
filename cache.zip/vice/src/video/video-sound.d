vice/src/video/video-sound.o: vice/src/video/video-sound.c \
 retrodep/archdep.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h vice/src/archapi.h vice/src/log.h \
 vice/src/machine.h vice/src/types.h vice/src/vice.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/sound.h \
 vice/src/vice.h vice/src/viewport.h vice/src/video/video-sound.h \
 vice/src/video.h
