vice/src/vic20/vic20mem.o: vice/src/vic20/vic20mem.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/cartio.h \
 vice/src/types.h vice/src/vice.h vice/src/cartridge.h vice/src/sound.h \
 vice/src/log.h vice/src/machine.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/vsyncapi.h vice/src/mem.h vice/src/monitor.h \
 vice/src/monitor/asm.h vice/src/types.h vice/src/ram.h \
 vice/src/resources.h vice/src/sid/sid-resources.h vice/src/sid/sid.h \
 vice/src/sound.h vice/src/uiapi.h vice/src/via.h vice/src/vic20/vic.h \
 vice/src/vic20/vic-mem.h vice/src/vic20/vic20.h \
 vice/src/vic20/vic20-resources.h vice/src/vic20/cart/vic20cartmem.h \
 vice/src/vic20/vic20ieeevia.h vice/src/vic20/vic20mem.h \
 vice/src/vic20/vic20memrom.h vice/src/vic20/vic20rom.h \
 vice/src/vic20/vic20via.h
