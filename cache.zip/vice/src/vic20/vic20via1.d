vice/src/vic20/vic20via1.o: vice/src/vic20/vic20via1.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h \
 vice/src/datasette/datasette.h vice/src/types.h vice/src/vice.h \
 vice/src/interrupt.h vice/src/debug.h vice/src/types.h vice/src/log.h \
 vice/src/joyport/joyport.h vice/src/snapshot.h \
 retrodep/snapshot_stream.h vice/src/keyboard.h vice/src/lib.h \
 vice/src/maincpu.h vice/src/mainlock.h vice/src/vsyncapi.h \
 vice/src/tapeport/tapeport.h vice/src/via.h vice/src/vic20/vic20.h \
 vice/src/vic20/vic.h vice/src/vic20/vic20iec.h vice/src/vic20/vic20via.h
