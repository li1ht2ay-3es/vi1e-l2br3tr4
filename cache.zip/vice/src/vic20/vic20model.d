vice/src/vic20/vic20model.o: vice/src/vic20/vic20model.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h \
 vice/src/vic20/vic20-resources.h vice/src/vic20/cart/vic20cart.h \
 vice/src/types.h vice/src/vice.h vice/src/vic20/vic20mem.h \
 vice/src/mem.h vice/src/types.h vice/src/vic20/vic20model.h \
 vice/src/machine.h vice/src/resources.h
