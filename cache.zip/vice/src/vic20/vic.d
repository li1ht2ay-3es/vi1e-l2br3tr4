vice/src/vic20/vic.o: vice/src/vic20/vic.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/videoarch.h \
 retrodep/archdep.h vice/src/archapi.h vice/src/clkguard.h \
 vice/src/types.h vice/src/vice.h vice/src/lib.h vice/src/debug.h \
 vice/src/log.h vice/src/machine.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/vsyncapi.h vice/src/mem.h vice/src/monitor.h \
 vice/src/monitor/asm.h vice/src/types.h vice/src/raster/raster-line.h \
 vice/src/raster/raster-modes.h vice/src/raster/raster-cache.h \
 vice/src/raster/raster-sprite-cache.h vice/src/resources.h \
 vice/src/screenshot.h vice/src/viewport.h vice/src/snapshot.h \
 retrodep/snapshot_stream.h vice/src/vic20/vic-cmdline-options.h \
 vice/src/vic20/vic-draw.h vice/src/vic20/vic-mem.h \
 vice/src/vic20/vic-resources.h vice/src/vic20/vic-snapshot.h \
 vice/src/vic20/vic-timing.h vice/src/vic20/vic-color.h \
 vice/src/vic20/vic.h vice/src/vic20/victypes.h vice/src/raster/raster.h \
 vice/src/vic20/vic20.h vice/src/vic20/vic20-resources.h \
 vice/src/vic20/vic20mem.h vice/src/vic20/vic20memrom.h \
 vice/src/viewport.h vice/src/vsync.h
