vice/src/vic20/vic20-resources.o: vice/src/vic20/vic20-resources.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/kbd.h \
 vice/src/keyboard.h vice/src/types.h vice/src/vice.h vice/src/lib.h \
 vice/src/debug.h vice/src/machine.h vice/src/mem.h vice/src/resources.h \
 vice/src/uiapi.h vice/src/util.h vice/src/vic20/vic20-resources.h \
 vice/src/vic20/vic20mem.h vice/src/types.h vice/src/vic20/vic20rom.h \
 vice/src/vic20/vic-resources.h
