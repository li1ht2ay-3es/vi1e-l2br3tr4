vice/src/vic20/vic20cpu.o: vice/src/vic20/vic20cpu.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/monitor.h \
 vice/src/types.h vice/src/vice.h vice/src/monitor/asm.h vice/src/types.h \
 vice/src/vic20/vic-cycle.h vice/src/vic20/../mainviccpu.c \
 vice/src/vic20/../vice.h vice/src/vic20/../6510core.h \
 vice/src/vic20/../alarm.h vice/src/vic20/../types.h retrodep/archdep.h \
 vice/src/archapi.h vice/src/vic20/../clkguard.h \
 vice/src/vic20/../debug.h vice/src/vic20/../interrupt.h \
 vice/src/vic20/../log.h vice/src/vic20/../machine.h \
 vice/src/vic20/../maincpu.h vice/src/vic20/../mainlock.h \
 vice/src/vic20/../vsyncapi.h vice/src/vic20/../mem.h \
 vice/src/vic20/../monitor.h vice/src/vic20/../mos6510.h \
 vice/src/vic20/../snapshot.h retrodep/snapshot_stream.h \
 vice/src/vic20/../traps.h vice/src/vic20/../6510dtvcore.c
