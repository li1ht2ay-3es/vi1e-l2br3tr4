vice/src/vic20/cart/vic20cartmem.o: vice/src/vic20/cart/vic20cartmem.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h \
 vice/src/vic20/cart/behrbonz.h vice/src/types.h vice/src/vice.h \
 vice/src/c64/cart/c64acia.h vice/src/cartridge.h vice/src/types.h \
 vice/src/sound.h vice/src/c64/cart/digimax.h vice/src/sound.h \
 vice/src/c64/cart/ds12c887rtc.h vice/src/vic20/cart/finalexpansion.h \
 vice/src/c64/cart/georam.h vice/src/vic20/cart/ioramcart.h \
 vice/src/snapshot.h retrodep/snapshot_stream.h \
 vice/src/vic20/cart/megacart.h vice/src/machine.h vice/src/mem.h \
 vice/src/resources.h vice/src/c64/cart/sfx_soundexpander.h \
 vice/src/c64/cart/sfx_soundsampler.h vice/src/sidcart.h \
 vice/src/snapshot.h vice/src/vic20/cart/ultimem.h \
 vice/src/vic20/vic20mem.h vice/src/vic20/cart/vic20cart.h \
 vice/src/vic20/cart/vic20cartmem.h vice/src/vic20/cart/vic20-generic.h \
 vice/src/vic20/cart/vic20-ieee488.h vice/src/vic20/cart/vic20-midi.h \
 vice/src/midi.h vice/src/vic20/cart/vic-fp.h
