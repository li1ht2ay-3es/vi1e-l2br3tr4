vice/src/vic20/vic-cycle.o: vice/src/vic20/vic-cycle.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/maincpu.h \
 vice/src/mainlock.h vice/src/vice.h vice/src/types.h vice/src/vsyncapi.h \
 vice/src/mem.h vice/src/raster/raster.h vice/src/types.h \
 vice/src/vic20/vic.h vice/src/vic20/victypes.h \
 vice/src/vic20/vic20-resources.h vice/src/vic20/vic20mem.h \
 vice/src/vic20/vic20memrom.h vice/src/vic20/vic20.h vice/src/viewport.h \
 vice/src/vic20/vic-cycle.h
