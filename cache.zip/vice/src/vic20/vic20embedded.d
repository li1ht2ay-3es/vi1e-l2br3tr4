vice/src/vic20/vic20embedded.o: vice/src/vic20/vic20embedded.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/embedded.h \
 vice/src/vice.h vice/src/types.h vice/src/palette.h vice/src/machine.h \
 vice/src/vic20/vic20mem.h vice/src/mem.h vice/src/types.h \
 include/embedded/vic20chargen.h include/embedded/vic_colodore_vic_vpl.h \
 include/embedded/vic_mike_ntsc_vpl.h include/embedded/vic_mike_pal_vpl.h \
 include/embedded/vic_vice_vpl.h
