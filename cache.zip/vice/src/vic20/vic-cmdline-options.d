vice/src/vic20/vic-cmdline-options.o: \
 vice/src/vic20/vic-cmdline-options.c vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/cmdline.h \
 vice/src/machine.h vice/src/types.h vice/src/vice.h \
 vice/src/raster/raster-cmdline-options.h vice/src/resources.h \
 vice/src/vic20/vic-cmdline-options.h vice/src/vic20/vic-resources.h \
 vice/src/vic20/vic.h vice/src/types.h vice/src/vic20/victypes.h \
 vice/src/raster/raster.h
