vice/src/cbm2/cbm5x0-resources.o: vice/src/cbm2/cbm5x0-resources.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/archdep.h \
 vice/src/archapi.h vice/src/cbm2/cbm2-resources.h vice/src/cbm2/cbm2.h \
 vice/src/mem.h vice/src/types.h vice/src/vice.h vice/src/cbm2/cbm2cia.h \
 vice/src/types.h vice/src/cbm2/cbm2mem.h vice/src/cbm2/cbm2model.h \
 vice/src/cbm2/cbm2rom.h vice/src/cbm2/cbm2tpi.h vice/src/cia.h \
 retrodep/kbd.h vice/src/keyboard.h vice/src/lib.h vice/src/debug.h \
 vice/src/machine.h vice/src/resources.h vice/src/sid/sid-resources.h \
 vice/src/util.h vice/src/vicii/vicii-resources.h vice/src/vicii.h \
 vice/src/vsync.h vice/src/cbm2/cbm2-common-resources.c
