vice/src/cbm2/cbm2cpu.o: vice/src/cbm2/cbm2cpu.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/cbm2/cbm2.h \
 vice/src/mem.h vice/src/types.h vice/src/vice.h vice/src/types.h \
 vice/src/cbm2/../maincpu.c vice/src/cbm2/../vice.h \
 vice/src/cbm2/../6510core.h vice/src/cbm2/../alarm.h \
 vice/src/cbm2/../types.h retrodep/archdep.h vice/src/archapi.h \
 vice/src/cbm2/../clkguard.h vice/src/cbm2/../debug.h \
 vice/src/cbm2/../interrupt.h vice/src/cbm2/../log.h \
 vice/src/cbm2/../machine.h vice/src/cbm2/../maincpu.h \
 vice/src/cbm2/../mainlock.h vice/src/cbm2/../vsyncapi.h \
 vice/src/cbm2/../mem.h vice/src/cbm2/../monitor.h \
 vice/src/cbm2/../monitor/asm.h vice/src/cbm2/../mos6510.h \
 vice/src/cbm2/../h6809regs.h vice/src/cbm2/../snapshot.h \
 retrodep/snapshot_stream.h vice/src/cbm2/../traps.h \
 vice/src/cbm2/../6510core.c
