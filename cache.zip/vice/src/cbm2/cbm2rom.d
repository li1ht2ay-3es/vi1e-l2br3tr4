vice/src/cbm2/cbm2rom.o: vice/src/cbm2/cbm2rom.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/autostart.h \
 vice/src/types.h vice/src/vice.h vice/src/cbm2/cbm2.h vice/src/mem.h \
 vice/src/cbm2/cbm2mem.h vice/src/types.h vice/src/cbm2/cbm2rom.h \
 vice/src/crtc/crtc.h vice/src/kbdbuf.h vice/src/lib.h vice/src/debug.h \
 vice/src/log.h vice/src/machine.h vice/src/resources.h \
 vice/src/sysfile.h vice/src/tape.h vice/src/util.h
