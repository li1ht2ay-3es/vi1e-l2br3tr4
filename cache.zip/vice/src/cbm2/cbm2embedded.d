vice/src/cbm2/cbm2embedded.o: vice/src/cbm2/cbm2embedded.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/embedded.h \
 vice/src/vice.h vice/src/types.h vice/src/palette.h vice/src/machine.h \
 include/embedded/cbm2basic128.h include/embedded/cbm2basic256.h \
 include/embedded/cbm2chargen600.h include/embedded/cbm2chargen700.h \
 include/embedded/cbm2kernal.h include/embedded/crtc_amber_vpl.h \
 include/embedded/crtc_green_vpl.h include/embedded/crtc_white_vpl.h
