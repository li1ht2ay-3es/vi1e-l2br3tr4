vice/src/cbm2/cbm2memsnapshot.o: vice/src/cbm2/cbm2memsnapshot.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h \
 vice/src/cbm2/cbm2-resources.h vice/src/cbm2/cbm2.h vice/src/mem.h \
 vice/src/types.h vice/src/vice.h vice/src/cbm2/cbm2mem.h \
 vice/src/types.h vice/src/cbm2/cbm2memsnapshot.h vice/src/cbm2/cbm2rom.h \
 vice/src/log.h vice/src/machine.h vice/src/resources.h \
 vice/src/snapshot.h retrodep/snapshot_stream.h
