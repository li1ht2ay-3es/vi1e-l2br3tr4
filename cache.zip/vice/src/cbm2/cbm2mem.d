vice/src/cbm2/cbm2mem.o: vice/src/cbm2/cbm2mem.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h retrodep/archdep.h \
 vice/src/archapi.h vice/src/cartio.h vice/src/types.h vice/src/vice.h \
 vice/src/cartridge.h vice/src/sound.h vice/src/cbm2/cbm2-resources.h \
 vice/src/cbm2/cbm2.h vice/src/mem.h vice/src/cbm2/cbm2acia.h \
 vice/src/types.h vice/src/cbm2/cbm2cart.h vice/src/cbm2/cbm2cia.h \
 vice/src/cbm2/cbm2mem.h vice/src/cbm2/cbm2model.h \
 vice/src/cbm2/cbm2tpi.h vice/src/cia.h vice/src/crtc/crtc-mem.h \
 vice/src/crtc/crtc.h vice/src/crtc/crtctypes.h vice/src/crtc/crtc.h \
 vice/src/raster/raster.h vice/src/kbdbuf.h vice/src/machine.h \
 vice/src/maincpu.h vice/src/mainlock.h vice/src/vsyncapi.h \
 vice/src/monitor.h vice/src/monitor/asm.h vice/src/ram.h \
 vice/src/resources.h vice/src/sid/sid.h vice/src/sound.h \
 vice/src/sid/sid-resources.h vice/src/tpi.h vice/src/vsync.h
