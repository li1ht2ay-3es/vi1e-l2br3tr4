vice/src/cbm2/cbm2.o: vice/src/cbm2/cbm2.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/alarm.h \
 vice/src/types.h vice/src/vice.h vice/src/attach.h vice/src/autostart.h \
 vice/src/joyport/bbrtc.h vice/src/types.h vice/src/cartio.h \
 vice/src/cartridge.h vice/src/sound.h \
 vice/src/cbm2/cbm2-cmdline-options.h vice/src/cbm2/cbm2-resources.h \
 vice/src/cbm2/cbm2-snapshot.h vice/src/cbm2/cbm2.h vice/src/mem.h \
 vice/src/cbm2/cbm2acia.h vice/src/cbm2/cbm2cia.h vice/src/cbm2/cbm2iec.h \
 vice/src/cbm2/cbm2model.h vice/src/cbm2/cbm2mem.h \
 vice/src/cbm2/cbm2tpi.h vice/src/cbm2ui.h vice/src/cia.h \
 vice/src/clkguard.h vice/src/crtc/crtc.h vice/src/datasette/datasette.h \
 vice/src/datasette/datasette-sound.h vice/src/debug.h \
 vice/src/cbm2/debugcart.h vice/src/diskimage.h \
 vice/src/drive/drive-cmdline-options.h vice/src/drive/drive-resources.h \
 vice/src/drive/drive-sound.h vice/src/drive/drive.h \
 vice/src/rtc/ds1216e.h vice/src/snapshot.h retrodep/snapshot_stream.h \
 vice/src/lib/p64/p64.h vice/src/lib/p64/p64config.h vice/src/lib.h \
 vice/src/debug.h vice/src/drive/drivetypes.h vice/src/drive/drive.h \
 vice/src/mos6510.h vice/src/r65c02.h vice/src/fliplist.h \
 vice/src/fsdevice.h vice/src/gfxoutput.h vice/src/iecdrive.h \
 vice/src/init.h vice/src/joyport/joyport.h vice/src/joyport/joystick.h \
 vice/src/kbdbuf.h vice/src/keyboard.h vice/src/log.h \
 vice/src/machine-drive.h vice/src/machine-printer.h \
 vice/src/machine-video.h vice/src/machine.h vice/src/maincpu.h \
 vice/src/mainlock.h vice/src/vsyncapi.h vice/src/monitor.h \
 vice/src/monitor/asm.h vice/src/network.h vice/src/joyport/paperclip64.h \
 vice/src/parallel.h vice/src/printer.h vice/src/resources.h \
 vice/src/rs232drv/rs232drv.h vice/src/samplerdrv/sampler.h \
 vice/src/joyport/sampler2bit.h vice/src/joyport/sampler4bit.h \
 vice/src/screenshot.h vice/src/viewport.h vice/src/serial.h \
 vice/src/sid/sid-cmdline-options.h vice/src/sid/sid-resources.h \
 vice/src/sid/sid.h vice/src/sound.h vice/src/tape.h \
 vice/src/tapeport/tapeport.h vice/src/tpi.h vice/src/traps.h \
 vice/src/mem.h vice/src/userport/userport.h \
 vice/src/userport/userport_4bit_sampler.h \
 vice/src/userport/userport_8bss.h vice/src/userport/userport_dac.h \
 vice/src/userport/userport_digimax.h \
 vice/src/userport/userport_joystick.h \
 vice/src/userport/userport_rtc_58321a.h \
 vice/src/userport/userport_rtc_ds1307.h vice/src/vice-event.h \
 vice/src/video.h vice/src/video/video-sound.h vice/src/viewport.h \
 vice/src/vsync.h vice/src/joyport/mouse.h
