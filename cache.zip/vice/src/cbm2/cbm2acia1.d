vice/src/cbm2/cbm2acia1.o: vice/src/cbm2/cbm2acia1.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/cbm2/cbm2acia.h \
 vice/src/types.h vice/src/vice.h vice/src/maincpu.h vice/src/mainlock.h \
 vice/src/types.h vice/src/vsyncapi.h vice/src/cbm2/cbm2.h vice/src/mem.h \
 vice/src/tpi.h vice/src/acia.h vice/src/aciacore.c vice/src/acia.h \
 vice/src/alarm.h vice/src/clkguard.h vice/src/cmdline.h \
 vice/src/interrupt.h vice/src/debug.h vice/src/log.h vice/src/machine.h \
 vice/src/resources.h vice/src/rs232drv/rs232drv.h vice/src/snapshot.h \
 retrodep/snapshot_stream.h
