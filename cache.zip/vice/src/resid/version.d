vice/src/resid/version.o: vice/src/resid/version.cc \
 vice/src/resid/resid-config.h vice/src/resid/siddefs.h
