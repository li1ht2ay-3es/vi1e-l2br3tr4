vice/src/resid/pot.o: vice/src/resid/pot.cc vice/src/resid/pot.h \
 vice/src/resid/resid-config.h vice/src/resid/siddefs.h
