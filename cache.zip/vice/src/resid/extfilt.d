vice/src/resid/extfilt.o: vice/src/resid/extfilt.cc \
 vice/src/resid/extfilt.h vice/src/resid/resid-config.h \
 vice/src/resid/siddefs.h
