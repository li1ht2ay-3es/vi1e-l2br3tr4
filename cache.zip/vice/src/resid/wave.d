vice/src/resid/wave.o: vice/src/resid/wave.cc vice/src/resid/wave.h \
 vice/src/resid/resid-config.h vice/src/resid/siddefs.h \
 vice/src/resid/dac.h vice/src/resid/wave6581__ST.h \
 vice/src/resid/wave6581_P_T.h vice/src/resid/wave6581_PS_.h \
 vice/src/resid/wave6581_PST.h vice/src/resid/wave8580__ST.h \
 vice/src/resid/wave8580_P_T.h vice/src/resid/wave8580_PS_.h \
 vice/src/resid/wave8580_PST.h
