vice/src/resid/envelope.o: vice/src/resid/envelope.cc \
 vice/src/resid/envelope.h vice/src/resid/resid-config.h \
 vice/src/resid/siddefs.h vice/src/resid/dac.h
