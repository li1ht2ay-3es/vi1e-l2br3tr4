vice/src/resid/filter8580new.o: vice/src/resid/filter8580new.cc \
 vice/src/resid/filter8580new.h vice/src/resid/resid-config.h \
 vice/src/resid/siddefs.h vice/src/resid/dac.h vice/src/resid/spline.h
