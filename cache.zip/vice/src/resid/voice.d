vice/src/resid/voice.o: vice/src/resid/voice.cc vice/src/resid/voice.h \
 vice/src/resid/resid-config.h vice/src/resid/siddefs.h \
 vice/src/resid/wave.h vice/src/resid/envelope.h
