vice/src/resid/dac.o: vice/src/resid/dac.cc vice/src/resid/dac.h
