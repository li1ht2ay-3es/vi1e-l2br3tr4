vice/src/resid/sid.o: vice/src/resid/sid.cc vice/src/resid/sid.h \
 vice/src/resid/resid-config.h vice/src/resid/siddefs.h \
 vice/src/resid/voice.h vice/src/resid/wave.h vice/src/resid/envelope.h \
 vice/src/resid/filter8580new.h vice/src/resid/extfilt.h \
 vice/src/resid/pot.h
