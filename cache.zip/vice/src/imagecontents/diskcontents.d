vice/src/imagecontents/diskcontents.o: \
 vice/src/imagecontents/diskcontents.c vice/src/vice.h \
 include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h \
 vice/src/imagecontents/diskcontents-block.h \
 vice/src/imagecontents/diskcontents-iec.h \
 vice/src/imagecontents/diskcontents.h vice/src/imagecontents.h \
 vice/src/types.h vice/src/vice.h vice/src/lib.h vice/src/debug.h \
 vice/src/machine-bus.h vice/src/machine.h vice/src/serial.h \
 vice/src/attach.h vice/src/vdrive/vdrive-internal.h
