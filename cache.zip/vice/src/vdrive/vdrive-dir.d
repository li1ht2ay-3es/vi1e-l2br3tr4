vice/src/vdrive/vdrive-dir.o: vice/src/vdrive/vdrive-dir.c \
 vice/src/vice.h include/sysconfig.h \
 libretro-common/include/streams/file_stream_transforms.h \
 libretro-common/include/retro_common_api.h \
 libretro-common/include/streams/file_stream.h \
 libretro-common/include/libretro.h \
 libretro-common/include/retro_inline.h libretro-common/include/boolean.h \
 libretro-common/include/vfs/vfs_implementation.h \
 libretro-common/include/retro_environment.h \
 libretro-common/include/vfs/vfs.h include/config.h \
 libretro-common/include/retro_endianness.h vice/src/cbmdos.h \
 vice/src/types.h vice/src/vice.h vice/src/diskconstants.h \
 vice/src/diskimage.h vice/src/lib.h vice/src/debug.h vice/src/log.h \
 vice/src/types.h vice/src/vdrive/vdrive-bam.h \
 vice/src/vdrive/vdrive-dir.h vice/src/vdrive/vdrive.h
